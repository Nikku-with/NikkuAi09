import { boolean, index, integer, pgTable, primaryKey, text, timestamp, uniqueIndex, uuid, varchar } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  username: varchar("username", { length: 32 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: varchar("name", { length: 80 }).notNull(),
  nickname: varchar("nickname", { length: 80 }),
  bio: text("bio").notNull().default(""),
  avatarUrl: text("avatar_url"),
  branch: varchar("branch", { length: 80 }),
  semester: varchar("semester", { length: 40 }),
  contactHandle: varchar("contact_handle", { length: 160 }),
  theme: varchar("theme", { length: 20 }).notNull().default("rose"),
  isPrivate: boolean("is_private").notNull().default(false),
  inviteSetting: varchar("invite_setting", { length: 20 }).notNull().default("everyone"),
  notificationsMuted: boolean("notifications_muted").notNull().default(false),
  role: varchar("role", { length: 12 }).notNull().default("user"),
  restricted: boolean("restricted").notNull().default(false),
  deviceHash: varchar("device_hash", { length: 64 }),
  ipHash: varchar("ip_hash", { length: 64 }),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  activeSeconds: integer("active_seconds").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("users_device_idx").on(t.deviceHash), index("users_ip_idx").on(t.ipHash)]);

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("token_hash", { length: 64 }).notNull().unique(),
  deviceHash: varchar("device_hash", { length: 64 }),
  ipHash: varchar("ip_hash", { length: 64 }),
  adminUnlockedUntil: timestamp("admin_unlocked_until", { withTimezone: true }),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("sessions_user_idx").on(t.userId)]);

export const activities = pgTable("activities", {
  id: uuid("id").primaryKey().defaultRandom(),
  actorId: uuid("actor_id").references(() => users.id, { onDelete: "set null" }),
  targetId: uuid("target_id").references(() => users.id, { onDelete: "set null" }),
  action: varchar("action", { length: 70 }).notNull(),
  detail: text("detail").notNull().default(""),
  ipHash: varchar("ip_hash", { length: 64 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("activities_target_idx").on(t.targetId), index("activities_created_idx").on(t.createdAt)]);

export const securityAttempts = pgTable("security_attempts", {
  key: varchar("key", { length: 128 }).primaryKey(),
  count: integer("count").notNull().default(0),
  blockedUntil: timestamp("blocked_until", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const confessions = pgTable("confessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  subject: varchar("subject", { length: 120 }).notNull(),
  content: text("content").notNull(),
  contact: varchar("contact", { length: 180 }),
  status: varchar("status", { length: 16 }).notNull().default("pending"),
  adminNote: text("admin_note"),
  seenAt: timestamp("seen_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("confessions_user_idx").on(t.userId), index("confessions_status_idx").on(t.status)]);

export const conversations = pgTable("conversations", {
  id: uuid("id").primaryKey().defaultRandom(),
  kind: varchar("kind", { length: 12 }).notNull(),
  name: varchar("name", { length: 100 }),
  description: text("description"),
  avatarUrl: text("avatar_url"),
  inviteCode: varchar("invite_code", { length: 48 }).unique(),
  createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("conversations_updated_idx").on(t.updatedAt)]);

export const conversationMembers = pgTable("conversation_members", {
  conversationId: uuid("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  role: varchar("role", { length: 12 }).notNull().default("member"),
  joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
  lastReadAt: timestamp("last_read_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.conversationId, t.userId] }), index("members_user_idx").on(t.userId)]);

export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  conversationId: uuid("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  senderId: uuid("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull().default(""),
  attachmentUrl: text("attachment_url"),
  replyToId: uuid("reply_to_id"),
  forwardedFromId: uuid("forwarded_from_id"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}, (t) => [index("messages_conversation_idx").on(t.conversationId, t.createdAt)]);

export const messageReactions = pgTable("message_reactions", {
  messageId: uuid("message_id").notNull().references(() => messages.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  emoji: varchar("emoji", { length: 16 }).notNull(),
}, (t) => [primaryKey({ columns: [t.messageId, t.userId] })]);

export const drafts = pgTable("drafts", {
  conversationId: uuid("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.conversationId, t.userId] })]);

export const follows = pgTable("follows", {
  followerId: uuid("follower_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  followingId: uuid("following_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.followerId, t.followingId] })]);

export const posts = pgTable("posts", {
  id: uuid("id").primaryKey().defaultRandom(),
  authorId: uuid("author_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  caption: text("caption").notNull(),
  imageUrl: text("image_url"),
  audioUrl: text("audio_url"),
  audioStart: integer("audio_start").notNull().default(0),
  audioDuration: integer("audio_duration").notNull().default(30),
  filter: varchar("filter", { length: 20 }).notNull().default("original"),
  sourceConfessionId: uuid("source_confession_id").references(() => confessions.id, { onDelete: "set null" }),
  publishAt: timestamp("publish_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  mentionsDeliveredAt: timestamp("mentions_delivered_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("posts_publish_idx").on(t.publishAt)]);

export const comments = pgTable("comments", {
  id: uuid("id").primaryKey().defaultRandom(),
  postId: uuid("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("comments_post_idx").on(t.postId)]);

export const postReactions = pgTable("post_reactions", {
  postId: uuid("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  emoji: varchar("emoji", { length: 16 }).notNull(),
}, (t) => [primaryKey({ columns: [t.postId, t.userId] })]);

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 30 }).notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  body: text("body").notNull().default(""),
  link: text("link"),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("notifications_user_idx").on(t.userId, t.createdAt)]);

export const siteSettings = pgTable("site_settings", {
  key: varchar("key", { length: 60 }).primaryKey(),
  value: text("value").notNull().default(""),
});

export const media = pgTable("media", {
  id: uuid("id").primaryKey().defaultRandom(),
  ownerId: uuid("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  mime: varchar("mime", { length: 40 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
