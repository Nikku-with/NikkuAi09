import { and, desc, eq, gt, inArray, isNull, lte, or } from "drizzle-orm";
import { db } from "@/db";
import { conversationMembers, conversations, messages, posts, users } from "@/db/schema";
import { notify } from "@/lib/server";

async function conversationBetween(authorId: string, targetId: string) {
  const mine = await db.select({ conversation: conversations }).from(conversations).innerJoin(conversationMembers, eq(conversationMembers.conversationId, conversations.id)).where(and(eq(conversationMembers.userId, authorId), inArray(conversations.kind, ["direct", "support"]))).orderBy(desc(conversations.updatedAt)).limit(100);
  for (const { conversation } of mine) {
    const members = await db.select({ userId: conversationMembers.userId }).from(conversationMembers).where(eq(conversationMembers.conversationId, conversation.id));
    if (members.length === 2 && members.some((member) => member.userId === targetId)) return conversation;
  }
  const [author] = await db.select({ role: users.role }).from(users).where(eq(users.id, authorId)).limit(1);
  const [target] = await db.select({ role: users.role }).from(users).where(eq(users.id, targetId)).limit(1);
  const [created] = await db.insert(conversations).values({ kind: author?.role === "owner" || target?.role === "owner" ? "support" : "direct", createdBy: authorId }).returning();
  await db.insert(conversationMembers).values([{ conversationId: created.id, userId: authorId, role: "member" }, { conversationId: created.id, userId: targetId, role: "member" }]);
  return created;
}

/** Deliver mentions when a scheduled post becomes visible. The claim prevents repeated sends on refresh. */
export async function deliverDuePostMentions() {
  const now = new Date();
  const due = await db.select().from(posts).where(and(lte(posts.publishAt, now), isNull(posts.mentionsDeliveredAt), or(isNull(posts.expiresAt), gt(posts.expiresAt, now)))).orderBy(posts.publishAt).limit(30);
  for (const post of due) {
    const [claimed] = await db.update(posts).set({ mentionsDeliveredAt: now }).where(and(eq(posts.id, post.id), isNull(posts.mentionsDeliveredAt))).returning({ id: posts.id });
    if (!claimed) continue;
    const handles = [...new Set([...post.caption.matchAll(/(?:^|\s)@([a-z0-9_.]{3,32})/gi)].map((match) => match[1].toLowerCase()))].slice(0, 15);
    if (!handles.length) continue;
    const mentioned = await db.select().from(users).where(inArray(users.username, handles));
    for (const target of mentioned) {
      if (target.id === post.authorId || target.restricted) continue;
      await notify(target.id, "mention", "You were mentioned in Cinema", "A story on the public screen mentioned you. ♡", `/?tab=cinema&post=${post.id}`);
      const conversation = await conversationBetween(post.authorId, target.id);
      await db.insert(messages).values({ conversationId: conversation.id, senderId: post.authorId, body: `You were mentioned in a Cinema post 💌\n${post.caption.slice(0, 160)}\nOpen Cinema to see the story.` });
      await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, conversation.id));
    }
  }
}
