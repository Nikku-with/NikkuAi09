import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { NextRequest, NextResponse } from "next/server";
import { and, eq, gt, lt } from "drizzle-orm";
import { db } from "@/db";
import { activities, notifications, posts, securityAttempts, sessions, siteSettings, users } from "@/db/schema";

const scrypt = promisify(scryptCallback);
const SESSION_COOKIE = "cinema_session";
const DEVICE_COOKIE = "cinema_device";
const cookieOptions = { httpOnly: true, sameSite: "lax" as const, secure: process.env.NODE_ENV === "production", path: "/" };

export type User = typeof users.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type Auth = { user: User; session: Session; ipHash: string | null; deviceHash: string | null };

export function hash(value: string) { return createHash("sha256").update(value).digest("hex"); }
export function signalHash(value: string) { return hash(`${process.env.SECURITY_PEPPER || "cinema"}:${value}`); }
export function clientIpHash(request: NextRequest) {
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip")?.trim();
  return ip ? signalHash(ip) : null;
}
export function deviceHash(request: NextRequest) {
  const device = request.cookies.get(DEVICE_COOKIE)?.value;
  return device && /^[a-f0-9]{64}$/.test(device) ? signalHash(device) : null;
}
export async function passwordHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = await scrypt(password, salt, 64) as Buffer;
  return `scrypt:${salt}:${derived.toString("hex")}`;
}
export async function verifyPassword(password: string, stored: string) {
  const [, salt, expected] = stored.split(":");
  if (!salt || !expected) return false;
  const derived = await scrypt(password, salt, 64) as Buffer;
  const expectedBuffer = Buffer.from(expected, "hex");
  return derived.length === expectedBuffer.length && timingSafeEqual(derived, expectedBuffer);
}
export function verifyAdminCode(value: string) {
  const secret = process.env.ADMIN_ACCESS_CODE;
  if (!secret || !value) return false;
  return timingSafeEqual(Buffer.from(hash(value), "hex"), Buffer.from(hash(secret), "hex"));
}

let setupPromise: Promise<void> | null = null;
export async function ensureSetup() {
  if (!setupPromise) setupPromise = (async () => {
    const ownerUsername = (process.env.OWNER_USERNAME || "").toLowerCase().replace(/^@/, "");
    if (ownerUsername && process.env.OWNER_PASSWORD) {
      const existing = await db.select({ id: users.id }).from(users).where(eq(users.username, ownerUsername)).limit(1);
      if (!existing.length) {
        await db.insert(users).values({ username: ownerUsername, passwordHash: await passwordHash(process.env.OWNER_PASSWORD), name: "Lervexx", nickname: "The founder", bio: "Behind the stories, never above them. Confess • connect • anonymously. ♡", role: "owner", theme: "rose" }).onConflictDoNothing();
      }
    }
    const defaults: Record<string, string> = {
      telegram_url: "https://t.me/Lervexxxx",
      telegram_handle: "@Lervexxxx",
      instagram_url: "",
      instagram_handle: "",
      home_announcement: "A little corner of campus for the things you never said out loud.",
      home_button_text: "",
      home_button_url: "",
      admin_note: "Want to help run Cinema? Send a message to @lervexxx.",
    };
    for (const [key, value] of Object.entries(defaults)) await db.insert(siteSettings).values({ key, value }).onConflictDoNothing();
    if (ownerUsername) {
      const [owner] = await db.select({ id: users.id }).from(users).where(eq(users.username, ownerUsername)).limit(1);
      if (owner) {
        const [firstPost] = await db.select({ id: posts.id }).from(posts).limit(1);
        if (!firstPost) await db.insert(posts).values({ authorId: owner.id, caption: "Welcome to Cinema. A space for the unsent words, the little what-ifs, and the stories that make campus feel a little smaller. 💌\n\nConfession requests stay in your private inbox until a moderator chooses to publish one here. The story is yours to tell.", imageUrl: "/images/cinema-hero.jpg", filter: "warm" });
      }
    }
  })();
  try { await setupPromise; } catch (error) { setupPromise = null; throw error; }
}

export async function getAuth(request: NextRequest): Promise<Auth | null> {
  const token = request.cookies.get(SESSION_COOKIE)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const rows = await db.select({ user: users, session: sessions }).from(sessions).innerJoin(users, eq(sessions.userId, users.id)).where(and(eq(sessions.tokenHash, hash(token)), gt(sessions.expiresAt, new Date()))).limit(1);
  if (!rows.length) return null;
  const device = deviceHash(request);
  if (rows[0].session.deviceHash && rows[0].session.deviceHash !== device) return null;
  return { ...rows[0], ipHash: clientIpHash(request), deviceHash: device };
}
export function publicUser(user: User) {
  return { id: user.id, username: user.username, name: user.name, nickname: user.nickname, bio: user.bio, avatarUrl: user.avatarUrl, branch: user.branch, semester: user.semester, contactHandle: user.contactHandle, theme: user.theme, isPrivate: user.isPrivate, inviteSetting: user.inviteSetting, notificationsMuted: user.notificationsMuted, role: user.role, restricted: user.restricted, activeSeconds: user.activeSeconds, lastLoginAt: user.lastLoginAt, createdAt: user.createdAt };
}
export function isAdmin(auth: Auth) { return (auth.user.role === "owner" || auth.user.role === "admin") && !!auth.session.adminUnlockedUntil && auth.session.adminUnlockedUntil > new Date(); }
export function requireUser(auth: Auth | null): asserts auth is Auth {
  if (!auth) throw new ApiError("Please log in to continue.", 401);
  if (auth.user.restricted) throw new ApiError("This account is restricted. Contact the owner for help.", 403);
}
export function requireAdmin(auth: Auth | null): asserts auth is Auth {
  requireUser(auth);
  if (!isAdmin(auth)) throw new ApiError("Unlock the admin workspace first.", 403);
}
export class ApiError extends Error { constructor(message: string, public status = 400) { super(message); } }
export function errorResponse(error: unknown) {
  if (error instanceof ApiError) return NextResponse.json({ error: error.message }, { status: error.status });
  console.error("Cinema API error", error);
  return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
}
export function checkOrigin(request: NextRequest) {
  const origin = request.headers.get("origin");
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host") || new URL(request.url).host;
  if (origin && new URL(origin).host !== host) throw new ApiError("Invalid request origin.", 403);
  if (request.headers.get("sec-fetch-site") === "cross-site") throw new ApiError("Cross-site request blocked.", 403);
}
export function value(input: unknown, max = 500) { return typeof input === "string" ? input.trim().slice(0, max) : ""; }
export function username(input: unknown) { return value(input, 32).toLowerCase().replace(/^@/, ""); }
export function validUsername(name: string) { return /^[a-z0-9_.]{3,32}$/.test(name) && !/^[._]|[._]$/.test(name); }
export async function logActivity(actorId: string | null, targetId: string | null, action: string, detail = "", ipHash: string | null = null) {
  await db.insert(activities).values({ actorId, targetId, action, detail: detail.slice(0, 300), ipHash });
}
export async function notify(userId: string, type: string, title: string, body = "", link: string | null = null) {
  await db.insert(notifications).values({ userId, type, title: title.slice(0, 160), body: body.slice(0, 500), link });
}
export async function createSession(response: NextResponse, userId: string, request: NextRequest) {
  const token = randomBytes(32).toString("hex");
  const device = request.cookies.get(DEVICE_COOKIE)?.value?.match(/^[a-f0-9]{64}$/)?.[0] || randomBytes(32).toString("hex");
  const hashedDevice = signalHash(device);
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ userId, tokenHash: hash(token), deviceHash: hashedDevice, ipHash: clientIpHash(request), expiresAt });
  response.cookies.set(SESSION_COOKIE, token, { ...cookieOptions, expires: expiresAt });
  response.cookies.set(DEVICE_COOKIE, device, { ...cookieOptions, expires: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) });
  return hashedDevice;
}
export function clearSessionCookie(response: NextResponse) { response.cookies.set(SESSION_COOKIE, "", { ...cookieOptions, maxAge: 0 }); }
export async function checkAttempt(key: string) {
  const [attempt] = await db.select().from(securityAttempts).where(eq(securityAttempts.key, key)).limit(1);
  if (attempt?.blockedUntil && attempt.blockedUntil > new Date()) throw new ApiError("Too many attempts. Please try again in 15 minutes.", 429);
}
export async function failedAttempt(key: string) {
  const [attempt] = await db.select().from(securityAttempts).where(eq(securityAttempts.key, key)).limit(1);
  const count = attempt && attempt.updatedAt > new Date(Date.now() - 15 * 60 * 1000) ? attempt.count + 1 : 1;
  await db.insert(securityAttempts).values({ key, count, blockedUntil: count >= 5 ? new Date(Date.now() + 15 * 60 * 1000) : null, updatedAt: new Date() }).onConflictDoUpdate({ target: securityAttempts.key, set: { count, blockedUntil: count >= 5 ? new Date(Date.now() + 15 * 60 * 1000) : null, updatedAt: new Date() } });
}
export async function clearAttempt(key: string) { await db.delete(securityAttempts).where(eq(securityAttempts.key, key)); }
export function isUuid(id: unknown): id is string { return typeof id === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id); }
export function safeExternalUrl(input: unknown) {
  const raw = value(input, 400);
  if (!raw) return "";
  try { const url = new URL(raw); return url.protocol === "https:" ? url.toString() : ""; } catch { return ""; }
}
