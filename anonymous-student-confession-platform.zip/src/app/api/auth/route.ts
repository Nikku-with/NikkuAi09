import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { ApiError, checkAttempt, checkOrigin, clearAttempt, clearSessionCookie, clientIpHash, createSession, deviceHash, ensureSetup, errorResponse, failedAttempt, getAuth, hash, logActivity, passwordHash, publicUser, username, validUsername, value, verifyPassword } from "@/lib/server";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    checkOrigin(request);
    const body = await request.json();
    const action = value(body.action, 20);
    if (action === "logout") {
      const auth = await getAuth(request);
      if (auth) {
        await db.delete(sessions).where(eq(sessions.id, auth.session.id));
        await logActivity(auth.user.id, auth.user.id, "logout", "Session ended", auth.ipHash);
      }
      const response = NextResponse.json({ ok: true });
      clearSessionCookie(response);
      return response;
    }
    await ensureSetup();
    const handle = username(body.username);
    const password = typeof body.password === "string" ? body.password : "";
    if (!validUsername(handle)) throw new ApiError("Username needs 3–32 letters, numbers, dots or underscores.");
    if (action === "register") {
      if (password.length < 8 || password.length > 128) throw new ApiError("Use a password between 8 and 128 characters.");
      const name = value(body.name, 80);
      if (name.length < 2) throw new ApiError("Please enter a display name.");
      const ip = clientIpHash(request);
      const device = deviceHash(request);
      if (device) {
        const existing = await db.select({ id: users.id, restricted: users.restricted }).from(users).where(eq(users.deviceHash, device));
        if (existing.some((row) => row.restricted)) throw new ApiError("This device is restricted. Contact the owner.", 403);
        if (existing.length >= 2) throw new ApiError("This browser already has two accounts. Sign in to an existing account instead.", 429);
      }
      const [created] = await db.insert(users).values({
        username: handle,
        passwordHash: await passwordHash(password),
        name,
        nickname: value(body.nickname, 80) || null,
        bio: value(body.bio, 500),
        branch: value(body.branch, 80) || null,
        semester: value(body.semester, 40) || null,
        contactHandle: value(body.contactHandle, 160) || null,
        avatarUrl: /^\/api\/media\/[0-9a-f-]{36}$/.test(value(body.avatarUrl, 100)) ? value(body.avatarUrl, 100) : null,
        theme: ["rose", "midnight", "cream"].includes(body.theme) ? body.theme : "rose",
        isPrivate: !!body.isPrivate,
        ipHash: ip,
        deviceHash: device,
        lastLoginAt: new Date(),
      }).onConflictDoNothing({ target: users.username }).returning();
      if (!created) throw new ApiError("That username is taken. Try another one.", 409);
      const response = NextResponse.json({ ok: true, user: publicUser(created) });
      const assignedDevice = await createSession(response, created.id, request);
      if (!device) await db.update(users).set({ deviceHash: assignedDevice }).where(eq(users.id, created.id));
      await logActivity(created.id, created.id, "register", "Account created", ip);
      return response;
    }
    if (action === "login") {
      const attemptKey = `login:${hash(`${handle}:${clientIpHash(request) || "unknown"}`)}`;
      await checkAttempt(attemptKey);
      const [user] = await db.select().from(users).where(eq(users.username, handle)).limit(1);
      if (!user || !await verifyPassword(password, user.passwordHash)) {
        await failedAttempt(attemptKey);
        throw new ApiError("Incorrect username or password.", 401);
      }
      if (user.restricted) throw new ApiError("This account is restricted. Contact the owner for help.", 403);
      await clearAttempt(attemptKey);
      const ip = clientIpHash(request);
      await db.update(users).set({ lastLoginAt: new Date(), ipHash: ip || user.ipHash }).where(eq(users.id, user.id));
      const response = NextResponse.json({ ok: true, user: publicUser(user) });
      await createSession(response, user.id, request);
      await logActivity(user.id, user.id, "login", "Signed in", ip);
      return response;
    }
    throw new ApiError("Unknown action.");
  } catch (error) { return errorResponse(error); }
}
