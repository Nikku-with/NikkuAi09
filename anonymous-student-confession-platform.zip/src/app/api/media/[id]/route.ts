import { NextRequest, NextResponse } from "next/server";
import { and, eq, gt, isNull, lte, or } from "drizzle-orm";
import { db } from "@/db";
import { conversationMembers, conversations, media, messages, posts, users } from "@/db/schema";
import { ApiError, errorResponse, getAuth, isAdmin, isUuid, requireUser } from "@/lib/server";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await getAuth(request);
    requireUser(auth);
    const { id } = await params;
    if (!isUuid(id)) throw new ApiError("Media not found.", 404);
    const [item] = await db.select().from(media).where(eq(media.id, id)).limit(1);
    if (!item) throw new ApiError("Media not found.", 404);
    const url = `/api/media/${id}`;
    if (item.ownerId !== auth.user.id && !isAdmin(auth)) {
      const [avatar, publicPost, group, attachment] = await Promise.all([
        db.select({ id: users.id }).from(users).where(eq(users.avatarUrl, url)).limit(1),
        db.select({ id: posts.id }).from(posts).where(and(or(eq(posts.imageUrl, url), eq(posts.audioUrl, url)), lte(posts.publishAt, new Date()), or(isNull(posts.expiresAt), gt(posts.expiresAt, new Date())))).limit(1),
        db.select({ id: conversations.id }).from(conversations).where(eq(conversations.avatarUrl, url)).limit(1),
        db.select({ conversationId: messages.conversationId }).from(messages).where(and(eq(messages.attachmentUrl, url), isNull(messages.deletedAt))).limit(10),
      ]);
      let permitted = !!avatar.length || !!publicPost.length;
      const privateIds = [...group.map((g) => g.id), ...attachment.map((m) => m.conversationId)];
      if (!permitted && privateIds.length) {
        for (const conversationId of privateIds) {
          const [member] = await db.select({ userId: conversationMembers.userId }).from(conversationMembers).where(and(eq(conversationMembers.conversationId, conversationId), eq(conversationMembers.userId, auth.user.id))).limit(1);
          if (member) { permitted = true; break; }
        }
      }
      if (!permitted) throw new ApiError("Media unavailable.", 403);
    }
    return new NextResponse(new Uint8Array(Buffer.from(item.content, "base64")), {
      headers: { "Content-Type": item.mime, "X-Content-Type-Options": "nosniff", "Content-Disposition": "inline", "Cache-Control": "private, max-age=3600" },
    });
  } catch (error) { return errorResponse(error); }
}
