import { NextRequest, NextResponse } from "next/server";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";
import { ApiError, checkOrigin, errorResponse, getAuth, requireUser } from "@/lib/server";

export const dynamic = "force-dynamic";

function detectMime(buffer: Buffer) {
  if (buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "image/png";
  if (buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255) return "image/jpeg";
  if (["GIF87a", "GIF89a"].includes(buffer.subarray(0, 6).toString("ascii"))) return "image/gif";
  if (buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  if (buffer.subarray(0, 3).toString("ascii") === "ID3" || (buffer[0] === 255 && (buffer[1] & 0xe0) === 0xe0)) return "audio/mpeg";
  return null;
}

export async function POST(request: NextRequest) {
  try {
    checkOrigin(request);
    const auth = await getAuth(request);
    requireUser(auth);
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) throw new ApiError("Choose a file to upload.");
    if (!file.size || file.size > 8 * 1024 * 1024) throw new ApiError("Maximum upload size is 8 MB.");
    const bytes = Buffer.from(await file.arrayBuffer());
    const mime = detectMime(bytes);
    if (!mime) throw new ApiError("Only PNG, JPG, GIF, WebP or MP3 files are supported.");
    if (!mime.startsWith("audio/") && bytes.length > 5 * 1024 * 1024) throw new ApiError("Images and GIFs must be smaller than 5 MB.");
    const recent = await db.select({ id: media.id }).from(media).where(and(eq(media.ownerId, auth.user.id), gt(media.createdAt, new Date(Date.now() - 60 * 60 * 1000))));
    if (recent.length >= 25) throw new ApiError("Upload limit reached. Try again later.", 429);
    const [saved] = await db.insert(media).values({ ownerId: auth.user.id, mime, content: bytes.toString("base64") }).returning({ id: media.id });
    return NextResponse.json({ ok: true, url: `/api/media/${saved.id}`, mime });
  } catch (error) { return errorResponse(error); }
}
