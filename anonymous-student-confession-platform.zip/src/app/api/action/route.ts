import { randomBytes } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gt, inArray, isNull, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { activities, comments, confessions, conversationMembers, conversations, drafts, follows, messageReactions, messages, notifications, postReactions, posts, sessions, siteSettings, users } from "@/db/schema";
import { ApiError, checkAttempt, checkOrigin, clearAttempt, ensureSetup, errorResponse, failedAttempt, getAuth, hash, isAdmin, isUuid, logActivity, notify, passwordHash, publicUser, requireAdmin, requireUser, safeExternalUrl, username, validUsername, value, verifyAdminCode, verifyPassword } from "@/lib/server";

export const dynamic = "force-dynamic";
type Auth = NonNullable<Awaited<ReturnType<typeof getAuth>>>;
const mediaUrl = (input: unknown) => /^\/api\/media\/[0-9a-f-]{36}$/.test(value(input, 100)) ? value(input, 100) : null;
const emojis = ["❤️", "😂", "🥹", "😮", "🔥", "👏", "💌", "👍", "😢", "✨"];
const json = (data: Record<string, unknown> = {}) => NextResponse.json({ ok: true, ...data });
const dateOrNull = (input: unknown) => {
  if (!input) return null;
  const date = new Date(String(input));
  return Number.isFinite(date.getTime()) ? date : null;
};

async function findUser(handle: unknown) {
  const [target] = await db.select().from(users).where(eq(users.username, username(handle))).limit(1);
  if (!target || target.restricted) throw new ApiError("Account not found.", 404);
  return target;
}
async function membership(conversationId: unknown, userId: string) {
  if (!isUuid(conversationId)) throw new ApiError("Invalid conversation.");
  const [row] = await db.select({ member: conversationMembers, conversation: conversations }).from(conversationMembers).innerJoin(conversations, eq(conversationMembers.conversationId, conversations.id)).where(and(eq(conversationMembers.conversationId, conversationId), eq(conversationMembers.userId, userId))).limit(1);
  if (!row) throw new ApiError("You are not in this conversation.", 403);
  return row;
}
async function groupManager(conversationId: unknown, auth: Auth) {
  const row = await membership(conversationId, auth.user.id);
  if (row.conversation.kind !== "group" || !["owner", "admin"].includes(row.member.role)) throw new ApiError("Only group admins can do that.", 403);
  return row;
}
async function getOrCreateDirect(a: string, b: string) {
  const mine = await db.select({ conversation: conversations }).from(conversations).innerJoin(conversationMembers, eq(conversationMembers.conversationId, conversations.id)).where(and(eq(conversationMembers.userId, a), inArray(conversations.kind, ["direct", "support"]))).orderBy(desc(conversations.updatedAt)).limit(100);
  for (const { conversation } of mine) {
    const members = await db.select({ userId: conversationMembers.userId }).from(conversationMembers).where(eq(conversationMembers.conversationId, conversation.id));
    if (members.length === 2 && members.some((m) => m.userId === b)) return conversation;
  }
  const [target] = await db.select({ role: users.role }).from(users).where(eq(users.id, b)).limit(1);
  const [sender] = await db.select({ role: users.role }).from(users).where(eq(users.id, a)).limit(1);
  const kind = target?.role === "owner" || sender?.role === "owner" ? "support" : "direct";
  const [created] = await db.insert(conversations).values({ kind, createdBy: a }).returning();
  await db.insert(conversationMembers).values([{ conversationId: created.id, userId: a, role: "member" }, { conversationId: created.id, userId: b, role: "member" }]);
  return created;
}
async function mentionUsers(text: string, authorId: string, type: string, link: string) {
  const handles = [...new Set([...text.matchAll(/(?:^|\s)@([a-z0-9_.]{3,32})/gi)].map((m) => m[1].toLowerCase()))].slice(0, 15);
  if (!handles.length) return [] as (typeof users.$inferSelect)[];
  const found = await db.select().from(users).where(inArray(users.username, handles));
  const targets = found.filter((u) => u.id !== authorId && !u.restricted);
  for (const target of targets) await notify(target.id, "mention", "You were mentioned in Cinema", `Someone mentioned @${target.username} in a ${type}.`, link);
  return targets;
}
async function notifyMembers(conversationId: string, senderId: string, body: string) {
  const members = await db.select({ userId: conversationMembers.userId }).from(conversationMembers).where(and(eq(conversationMembers.conversationId, conversationId), ne(conversationMembers.userId, senderId)));
  for (const member of members) await notify(member.userId, "message", "New message in your inbox", body.slice(0, 120) || "Sent an attachment", `/?tab=inbox&chat=${conversationId}`);
}

export async function POST(request: NextRequest) {
  try {
    checkOrigin(request);
    await ensureSetup();
    const auth = await getAuth(request);
    requireUser(auth);
    const body = await request.json();
    const action = value(body.action, 40);
    const actor = auth.user.id;
    const now = new Date();

    if (action === "unlockAdmin") {
      const key = `admin:${hash(`${actor}:${auth.ipHash || "unknown"}`)}`;
      await checkAttempt(key);
      if (!verifyAdminCode(value(body.code, 200))) {
        await failedAttempt(key);
        await logActivity(actor, actor, "admin_unlock_failed", "Incorrect access code", auth.ipHash);
        throw new ApiError("Incorrect access code.", 403);
      }
      await clearAttempt(key);
      const until = new Date(Date.now() + 8 * 60 * 60 * 1000);
      await db.update(sessions).set({ adminUnlockedUntil: until }).where(eq(sessions.id, auth.session.id));
      if (auth.user.role === "user") await db.update(users).set({ role: "admin", updatedAt: now }).where(eq(users.id, actor));
      await logActivity(actor, actor, "admin_unlock", "Workspace unlocked for 8 hours", auth.ipHash);
      return json({ adminUnlocked: true, role: auth.user.role === "owner" ? "owner" : "admin" });
    }
    if (action === "heartbeat") {
      if (auth.session.lastSeenAt < new Date(Date.now() - 40_000)) {
        await db.update(users).set({ activeSeconds: sql`${users.activeSeconds} + 60` }).where(eq(users.id, actor));
        await db.update(sessions).set({ lastSeenAt: now }).where(eq(sessions.id, auth.session.id));
      }
      return json();
    }
    if (action === "updateProfile") {
      const nextName = value(body.name, 80);
      const nextUsername = username(body.username);
      if (nextName.length < 2 || !validUsername(nextUsername)) throw new ApiError("Enter a name and a valid username.");
      const changes: Partial<typeof users.$inferInsert> = {
        name: nextName, username: nextUsername, nickname: value(body.nickname, 80) || null,
        bio: value(body.bio, 500), branch: value(body.branch, 80) || null, semester: value(body.semester, 40) || null,
        contactHandle: value(body.contactHandle, 160) || null,
        theme: ["rose", "midnight", "cream"].includes(body.theme) ? body.theme : "rose",
        isPrivate: !!body.isPrivate, inviteSetting: body.inviteSetting === "nobody" ? "nobody" : "everyone",
        notificationsMuted: !!body.notificationsMuted, updatedAt: now,
      };
      if (body.avatarUrl === "") changes.avatarUrl = null;
      else if (mediaUrl(body.avatarUrl)) changes.avatarUrl = mediaUrl(body.avatarUrl);
      if (nextUsername !== auth.user.username) {
        const [taken] = await db.select({ id: users.id }).from(users).where(eq(users.username, nextUsername)).limit(1);
        if (taken) throw new ApiError("That username is already taken.", 409);
        await logActivity(actor, actor, "username_changed", `@${auth.user.username} → @${nextUsername}`, auth.ipHash);
      }
      if (nextName !== auth.user.name) await logActivity(actor, actor, "name_changed", `${auth.user.name} → ${nextName}`, auth.ipHash);
      if (!!body.isPrivate !== auth.user.isPrivate) await logActivity(actor, actor, "privacy_changed", body.isPrivate ? "Profile set to private" : "Profile set to public", auth.ipHash);
      const [updated] = await db.update(users).set(changes).where(eq(users.id, actor)).returning();
      await logActivity(actor, actor, "profile_updated", "Profile settings saved", auth.ipHash);
      return json({ user: publicUser(updated) });
    }
    if (action === "changePassword") {
      if (!await verifyPassword(typeof body.oldPassword === "string" ? body.oldPassword : "", auth.user.passwordHash)) throw new ApiError("Current password is incorrect.", 403);
      const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
      if (newPassword.length < 8 || newPassword.length > 128) throw new ApiError("New password must be 8–128 characters.");
      await db.update(users).set({ passwordHash: await passwordHash(newPassword), updatedAt: now }).where(eq(users.id, actor));
      await db.delete(sessions).where(and(eq(sessions.userId, actor), ne(sessions.id, auth.session.id)));
      await logActivity(actor, actor, "password_changed", "Other sessions signed out", auth.ipHash);
      return json();
    }
    if (action === "submitRequest") {
      const subject = value(body.subject, 120), content = value(body.content, 3000);
      if (subject.length < 3 || content.length < 15) throw new ApiError("Add a subject and at least 15 characters to your confession.");
      const recent = await db.select({ id: confessions.id }).from(confessions).where(and(eq(confessions.userId, actor), gt(confessions.createdAt, new Date(Date.now() - 10 * 60_000))));
      if (recent.length >= 5) throw new ApiError("You have sent several requests. Please wait a little before sending more.", 429);
      const [created] = await db.insert(confessions).values({ userId: actor, subject, content, contact: value(body.contact, 180) || null }).returning();
      const admins = await db.select({ id: users.id }).from(users).where(inArray(users.role, ["owner", "admin"]));
      for (const admin of admins) if (admin.id !== actor) await notify(admin.id, "request", "New confession request", subject, "/?tab=admin");
      await logActivity(actor, actor, "request_submitted", subject, auth.ipHash);
      return json({ request: created });
    }
    if (action === "follow") {
      const target = await findUser(body.username);
      if (target.id === actor) throw new ApiError("You cannot follow yourself.");
      const [existing] = await db.select().from(follows).where(and(eq(follows.followerId, actor), eq(follows.followingId, target.id))).limit(1);
      if (existing) {
        await db.delete(follows).where(and(eq(follows.followerId, actor), eq(follows.followingId, target.id)));
        await logActivity(actor, target.id, "unfollow", `@${target.username}`, auth.ipHash);
        return json({ following: false });
      }
      await db.insert(follows).values({ followerId: actor, followingId: target.id }).onConflictDoNothing();
      await notify(target.id, "follow", "A new follower", `@${auth.user.username} followed you.`, `/u/${auth.user.username}`);
      await logActivity(actor, target.id, "follow", `@${target.username}`, auth.ipHash);
      return json({ following: true });
    }
    if (action === "startChat") {
      const target = await findUser(body.username);
      if (target.id === actor) throw new ApiError("You cannot message yourself.");
      if (target.isPrivate && target.role !== "owner" && !isAdmin(auth)) throw new ApiError("This profile is private and does not accept direct messages. You can still send a confession request.", 403);
      const conversation = await getOrCreateDirect(actor, target.id);
      return json({ conversationId: conversation.id });
    }
    if (action === "sendMessage") {
      const row = await membership(body.conversationId, actor);
      if (row.conversation.kind !== "group" && !isAdmin(auth)) {
        const recipients = await db.select({ user: users }).from(conversationMembers).innerJoin(users, eq(conversationMembers.userId, users.id)).where(and(eq(conversationMembers.conversationId, row.conversation.id), ne(conversationMembers.userId, actor)));
        if (recipients.some(({ user }) => user.isPrivate && user.role !== "owner")) throw new ApiError("This person has made their profile private and is not accepting direct messages.", 403);
      }
      const text = value(body.text, 3000);
      const attachment = mediaUrl(body.attachmentUrl);
      if (!text && !attachment) throw new ApiError("Write a message or add an attachment.");
      const recent = await db.select({ id: messages.id }).from(messages).where(and(eq(messages.senderId, actor), gt(messages.createdAt, new Date(Date.now() - 15_000))));
      if (recent.length >= 8) throw new ApiError("Slow down a little before sending more messages.", 429);
      let scheduledAt = dateOrNull(body.scheduledAt);
      if (scheduledAt && (scheduledAt <= now || scheduledAt > new Date(Date.now() + 30 * 86400_000))) throw new ApiError("Schedule a message within the next 30 days.");
      if (scheduledAt && scheduledAt.getTime() < Date.now() + 30_000) scheduledAt = null;
      let replyToId: string | null = null;
      if (isUuid(body.replyToId)) {
        const [reply] = await db.select({ id: messages.id }).from(messages).where(and(eq(messages.id, body.replyToId), eq(messages.conversationId, row.conversation.id))).limit(1);
        if (reply) replyToId = reply.id;
      }
      const [created] = await db.insert(messages).values({ conversationId: row.conversation.id, senderId: actor, body: text, attachmentUrl: attachment, replyToId, scheduledAt }).returning();
      await db.update(conversations).set({ updatedAt: now }).where(eq(conversations.id, row.conversation.id));
      await db.delete(drafts).where(and(eq(drafts.conversationId, row.conversation.id), eq(drafts.userId, actor)));
      if (!scheduledAt) {
        await notifyMembers(row.conversation.id, actor, text);
        await mentionUsers(text, actor, "message", `/?tab=inbox&chat=${row.conversation.id}`);
      }
      await logActivity(actor, actor, scheduledAt ? "message_scheduled" : "message_sent", `${row.conversation.kind} chat`, auth.ipHash);
      return json({ message: created });
    }
    if (action === "saveDraft") {
      const row = await membership(body.conversationId, actor);
      const text = value(body.text, 3000);
      await db.insert(drafts).values({ conversationId: row.conversation.id, userId: actor, body: text, updatedAt: now }).onConflictDoUpdate({ target: [drafts.conversationId, drafts.userId], set: { body: text, updatedAt: now } });
      return json();
    }
    if (action === "reactMessage") {
      if (!isUuid(body.messageId)) throw new ApiError("Invalid message.");
      const [message] = await db.select().from(messages).where(eq(messages.id, body.messageId)).limit(1);
      if (!message || message.deletedAt) throw new ApiError("Message not found.", 404);
      await membership(message.conversationId, actor);
      const emoji = value(body.emoji, 16);
      if (!emojis.includes(emoji)) throw new ApiError("Choose a supported reaction.");
      const [existing] = await db.select().from(messageReactions).where(and(eq(messageReactions.messageId, message.id), eq(messageReactions.userId, actor))).limit(1);
      if (existing?.emoji === emoji) await db.delete(messageReactions).where(and(eq(messageReactions.messageId, message.id), eq(messageReactions.userId, actor)));
      else await db.insert(messageReactions).values({ messageId: message.id, userId: actor, emoji }).onConflictDoUpdate({ target: [messageReactions.messageId, messageReactions.userId], set: { emoji } });
      return json();
    }
    if (action === "deleteMessage") {
      if (!isUuid(body.messageId)) throw new ApiError("Invalid message.");
      const [message] = await db.select().from(messages).where(eq(messages.id, body.messageId)).limit(1);
      if (!message) throw new ApiError("Message not found.", 404);
      await membership(message.conversationId, actor);
      if (message.senderId !== actor && !isAdmin(auth)) throw new ApiError("You can only delete your own messages.", 403);
      await db.update(messages).set({ deletedAt: now, body: "", attachmentUrl: null }).where(eq(messages.id, message.id));
      await logActivity(actor, message.senderId, "message_deleted", message.id, auth.ipHash);
      return json();
    }
    if (action === "forwardMessage") {
      if (!isUuid(body.messageId)) throw new ApiError("Invalid message.");
      const [original] = await db.select().from(messages).where(eq(messages.id, body.messageId)).limit(1);
      if (!original || original.deletedAt || (original.scheduledAt && original.scheduledAt > now)) throw new ApiError("Message unavailable.", 404);
      await membership(original.conversationId, actor);
      const destination = await membership(body.conversationId, actor);
      const [forwarded] = await db.insert(messages).values({ conversationId: destination.conversation.id, senderId: actor, body: original.body, attachmentUrl: original.attachmentUrl, forwardedFromId: original.id }).returning();
      await db.update(conversations).set({ updatedAt: now }).where(eq(conversations.id, destination.conversation.id));
      await notifyMembers(destination.conversation.id, actor, `Forwarded: ${original.body}`);
      return json({ message: forwarded });
    }
    if (action === "createGroup") {
      const name = value(body.name, 100);
      if (name.length < 3) throw new ApiError("Group name needs at least 3 characters.");
      const handles: string[] = Array.isArray(body.members) ? [...new Set<string>((body.members as unknown[]).map((h) => username(h)))].slice(0, 25) : [];
      const invited = handles.length ? await db.select().from(users).where(inArray(users.username, handles)) : [];
      const allowed = invited.filter((u) => u.id !== actor && !u.restricted && u.inviteSetting === "everyone");
      const [group] = await db.insert(conversations).values({ kind: "group", name, description: value(body.description, 500), avatarUrl: mediaUrl(body.avatarUrl), inviteCode: randomBytes(12).toString("hex"), createdBy: actor }).returning();
      await db.insert(conversationMembers).values([{ conversationId: group.id, userId: actor, role: "owner" }, ...allowed.map((u) => ({ conversationId: group.id, userId: u.id, role: "member" }))]);
      for (const member of allowed) await notify(member.id, "group", "You were added to a group", name, `/?tab=inbox&chat=${group.id}`);
      await logActivity(actor, actor, "group_created", name, auth.ipHash);
      return json({ conversationId: group.id, added: allowed.length });
    }
    if (action === "joinGroup") {
      const code = value(body.code, 48);
      const [group] = await db.select().from(conversations).where(and(eq(conversations.inviteCode, code), eq(conversations.kind, "group"))).limit(1);
      if (!group) throw new ApiError("Invite link is invalid.", 404);
      await db.insert(conversationMembers).values({ conversationId: group.id, userId: actor, role: "member" }).onConflictDoNothing();
      await logActivity(actor, actor, "group_joined", group.name || "Group", auth.ipHash);
      return json({ conversationId: group.id });
    }
    if (action === "inviteMember") {
      const { conversation } = await groupManager(body.conversationId, auth);
      const target = await findUser(body.username);
      if (target.inviteSetting !== "everyone") throw new ApiError("This person is not accepting group invites.", 403);
      await db.insert(conversationMembers).values({ conversationId: conversation.id, userId: target.id, role: "member" }).onConflictDoNothing();
      await notify(target.id, "group", "You were added to a group", conversation.name || "Group", `/?tab=inbox&chat=${conversation.id}`);
      await logActivity(actor, target.id, "group_member_added", conversation.name || "Group", auth.ipHash);
      return json();
    }
    if (action === "groupRole") {
      const { conversation, member } = await groupManager(body.conversationId, auth);
      if (member.role !== "owner") throw new ApiError("Only the group creator can manage group admins.", 403);
      const target = await findUser(body.username);
      if (target.id === actor) throw new ApiError("You are the group creator.");
      const [existing] = await db.select().from(conversationMembers).where(and(eq(conversationMembers.conversationId, conversation.id), eq(conversationMembers.userId, target.id))).limit(1);
      if (!existing) throw new ApiError("Add this member first.");
      const role = body.role === "admin" ? "admin" : "member";
      await db.update(conversationMembers).set({ role }).where(and(eq(conversationMembers.conversationId, conversation.id), eq(conversationMembers.userId, target.id)));
      await logActivity(actor, target.id, "group_role_changed", `${conversation.name}: ${role}`, auth.ipHash);
      return json();
    }
    if (action === "editGroup") {
      const { conversation } = await groupManager(body.conversationId, auth);
      const changes: Partial<typeof conversations.$inferInsert> = { name: value(body.name, 100) || conversation.name, description: value(body.description, 500), avatarUrl: mediaUrl(body.avatarUrl) || conversation.avatarUrl, updatedAt: now };
      if (body.rotateLink) changes.inviteCode = randomBytes(12).toString("hex");
      await db.update(conversations).set(changes).where(eq(conversations.id, conversation.id));
      await logActivity(actor, actor, "group_edited", conversation.name || "Group", auth.ipHash);
      return json();
    }
    if (action === "leaveGroup") {
      const { conversation, member } = await membership(body.conversationId, actor);
      if (conversation.kind !== "group") throw new ApiError("This is not a group.");
      if (member.role === "owner") throw new ApiError("Group creators can delete the group instead of leaving.");
      await db.delete(conversationMembers).where(and(eq(conversationMembers.conversationId, conversation.id), eq(conversationMembers.userId, actor)));
      await logActivity(actor, actor, "group_left", conversation.name || "Group", auth.ipHash);
      return json();
    }
    if (action === "deleteGroup") {
      if (!isUuid(body.conversationId)) throw new ApiError("Invalid group.");
      const [group] = await db.select().from(conversations).where(and(eq(conversations.id, body.conversationId), eq(conversations.kind, "group"))).limit(1);
      if (!group) throw new ApiError("Group not found.", 404);
      if (group.createdBy !== actor && !isAdmin(auth)) throw new ApiError("Only the creator or an unlocked site admin can delete this group.", 403);
      await logActivity(actor, group.createdBy, "group_deleted", group.name || "Group", auth.ipHash);
      await db.delete(conversations).where(eq(conversations.id, group.id));
      return json();
    }
    if (action === "reactPost" || action === "commentPost" || action === "deleteComment") {
      if (action === "deleteComment") {
        if (!isUuid(body.commentId)) throw new ApiError("Invalid comment.");
        const [comment] = await db.select().from(comments).where(eq(comments.id, body.commentId)).limit(1);
        if (!comment) throw new ApiError("Comment not found.", 404);
        if (comment.userId !== actor && !isAdmin(auth)) throw new ApiError("You can only delete your own comment.", 403);
        await db.delete(comments).where(eq(comments.id, comment.id));
        return json();
      }
      if (!isUuid(body.postId)) throw new ApiError("Invalid post.");
      const [post] = await db.select().from(posts).where(and(eq(posts.id, body.postId), or(isNull(posts.expiresAt), gt(posts.expiresAt, now)))).limit(1);
      if (!post || post.publishAt > now) throw new ApiError("Post not found.", 404);
      if (action === "reactPost") {
        const emoji = value(body.emoji, 16);
        if (!emojis.includes(emoji)) throw new ApiError("Choose a supported reaction.");
        const [existing] = await db.select().from(postReactions).where(and(eq(postReactions.postId, post.id), eq(postReactions.userId, actor))).limit(1);
        if (existing?.emoji === emoji) await db.delete(postReactions).where(and(eq(postReactions.postId, post.id), eq(postReactions.userId, actor)));
        else await db.insert(postReactions).values({ postId: post.id, userId: actor, emoji }).onConflictDoUpdate({ target: [postReactions.postId, postReactions.userId], set: { emoji } });
        if (post.authorId !== actor && !existing) await notify(post.authorId, "reaction", "Someone reacted to your post", emoji, "/?tab=cinema");
        return json();
      }
      const text = value(body.text, 1000);
      if (text.length < 2) throw new ApiError("Write a comment first.");
      const [comment] = await db.insert(comments).values({ postId: post.id, userId: actor, body: text }).returning();
      if (post.authorId !== actor) await notify(post.authorId, "comment", "A new comment on your post", text.slice(0, 100), "/?tab=cinema");
      await mentionUsers(text, actor, "comment", "/?tab=cinema");
      return json({ comment });
    }
    if (action === "markNotification") {
      if (isUuid(body.id)) await db.update(notifications).set({ readAt: now }).where(and(eq(notifications.id, body.id), eq(notifications.userId, actor)));
      else await db.update(notifications).set({ readAt: now }).where(eq(notifications.userId, actor));
      return json();
    }
    if (action === "report") {
      const detail = value(body.detail, 500);
      if (detail.length < 10) throw new ApiError("Please describe what happened.");
      const admins = await db.select({ id: users.id }).from(users).where(inArray(users.role, ["owner", "admin"]));
      for (const admin of admins) await notify(admin.id, "report", "New safety report", `@${auth.user.username}: ${detail}`, "/?tab=admin");
      await logActivity(actor, actor, "report_sent", detail.slice(0, 100), auth.ipHash);
      return json();
    }

    // Everything below this line requires an unlocked admin session, not just a client-side tab.
    requireAdmin(auth);
    if (action === "reviewRequest") {
      if (!isUuid(body.id)) throw new ApiError("Invalid request.");
      const [original] = await db.select().from(confessions).where(eq(confessions.id, body.id)).limit(1);
      if (!original) throw new ApiError("Request not found.", 404);
      const status = ["pending", "approved", "declined"].includes(body.status) ? body.status : original.status;
      await db.update(confessions).set({ status, adminNote: value(body.adminNote, 500) || null, seenAt: now, updatedAt: now }).where(eq(confessions.id, original.id));
      if (status !== original.status) await notify(original.userId, "request", `Your request is ${status}`, value(body.adminNote, 500) || "See the update in your requests.", "/?tab=inbox&view=requests");
      await logActivity(actor, original.userId, "request_reviewed", `${original.subject}: ${status}`, auth.ipHash);
      return json();
    }
    if (action === "publishPost") {
      const caption = value(body.caption, 3000);
      if (caption.length < 3) throw new ApiError("Add a caption before publishing.");
      const publishAt = dateOrNull(body.publishAt) || now;
      const expiresAt = dateOrNull(body.expiresAt);
      if (publishAt > new Date(Date.now() + 90 * 86400_000)) throw new ApiError("Schedule within the next 90 days.");
      if (expiresAt && expiresAt <= publishAt) throw new ApiError("Expiry must be after the publish time.");
      let sourceConfessionId: string | null = null;
      if (isUuid(body.sourceConfessionId)) {
        const [source] = await db.select().from(confessions).where(eq(confessions.id, body.sourceConfessionId)).limit(1);
        if (!source || source.status !== "approved") throw new ApiError("Approve this confession before posting it.");
        sourceConfessionId = source.id;
      }
      const [post] = await db.insert(posts).values({ authorId: actor, caption, imageUrl: mediaUrl(body.imageUrl), audioUrl: mediaUrl(body.audioUrl), audioStart: Math.max(0, Math.min(3600, Number(body.audioStart) || 0)), audioDuration: Math.max(5, Math.min(180, Number(body.audioDuration) || 30)), filter: ["original", "rose", "noir", "warm"].includes(body.filter) ? body.filter : "original", sourceConfessionId, publishAt, expiresAt }).returning();
      if (publishAt <= now) await (await import("@/lib/scheduled")).deliverDuePostMentions();
      await logActivity(actor, null, "post_published", publishAt > now ? "Scheduled Cinema post" : "Cinema post published", auth.ipHash);
      return json({ post });
    }
    if (action === "deletePost") {
      if (!isUuid(body.id)) throw new ApiError("Invalid post.");
      await db.delete(posts).where(eq(posts.id, body.id));
      await logActivity(actor, null, "post_deleted", body.id, auth.ipHash);
      return json();
    }
    if (action === "updateSiteSetting") {
      if (auth.user.role !== "owner") throw new ApiError("Only the owner can edit public contact links.", 403);
      const key = value(body.key, 60);
      const allowed = ["telegram_url", "telegram_handle", "instagram_url", "instagram_handle", "home_announcement", "home_button_text", "home_button_url", "admin_note"];
      if (!allowed.includes(key)) throw new ApiError("Invalid setting.");
      const input = value(body.value, key === "home_announcement" ? 300 : 400);
      const updated = key.endsWith("_url") ? safeExternalUrl(input) : input;
      if (key.endsWith("_url") && input && !updated) throw new ApiError("Use a valid https:// link.");
      await db.insert(siteSettings).values({ key, value: updated }).onConflictDoUpdate({ target: siteSettings.key, set: { value: updated } });
      await logActivity(actor, null, "site_setting_changed", key, auth.ipHash);
      return json();
    }
    if (action === "setAdminRole") {
      if (auth.user.role !== "owner") throw new ApiError("Only the owner can manage site admins.", 403);
      if (!isUuid(body.userId)) throw new ApiError("Invalid account.");
      const [target] = await db.select().from(users).where(eq(users.id, body.userId)).limit(1);
      if (!target || target.role === "owner") throw new ApiError("Owner access cannot be changed.", 403);
      const role = body.role === "admin" ? "admin" : "user";
      await db.update(users).set({ role, updatedAt: now }).where(eq(users.id, target.id));
      if (role === "user") await db.update(sessions).set({ adminUnlockedUntil: null }).where(eq(sessions.userId, target.id));
      await notify(target.id, "admin", role === "admin" ? "Admin access granted" : "Admin access removed", "Your Cinema permissions were updated.", "/?tab=admin");
      await logActivity(actor, target.id, "admin_role_changed", `${target.username}: ${role}`, auth.ipHash);
      return json();
    }
    if (action === "restrictUser") {
      if (!isUuid(body.userId)) throw new ApiError("Invalid account.");
      const [target] = await db.select().from(users).where(eq(users.id, body.userId)).limit(1);
      if (!target || target.role === "owner" || (target.role === "admin" && auth.user.role !== "owner")) throw new ApiError("You cannot restrict this account.", 403);
      const restricted = !!body.restricted;
      await db.update(users).set({ restricted, updatedAt: now }).where(eq(users.id, target.id));
      if (restricted) await db.delete(sessions).where(eq(sessions.userId, target.id));
      await logActivity(actor, target.id, restricted ? "user_restricted" : "user_restored", `@${target.username}`, auth.ipHash);
      return json();
    }
    throw new ApiError("Unknown action.", 404);
  } catch (error) { return errorResponse(error); }
}
