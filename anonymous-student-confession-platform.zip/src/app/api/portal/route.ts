import { NextRequest, NextResponse } from "next/server";
import { and, asc, desc, eq, gt, ilike, inArray, isNull, lte, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { activities, comments, confessions, conversationMembers, conversations, drafts, follows, messageReactions, messages, notifications, postReactions, posts, sessions, siteSettings, users } from "@/db/schema";
import { ApiError, ensureSetup, errorResponse, getAuth, isAdmin, isUuid, logActivity, publicUser, requireAdmin, requireUser, username, value } from "@/lib/server";

export const dynamic = "force-dynamic";
const compactUser = (user: typeof users.$inferSelect) => ({ id: user.id, username: user.username, name: user.name, nickname: user.nickname, avatarUrl: user.avatarUrl, bio: user.bio, branch: user.branch, semester: user.semester, isPrivate: user.isPrivate, role: user.role, theme: user.theme, contactHandle: user.isPrivate ? null : user.contactHandle });
const countOf = async (table: typeof confessions | typeof messages | typeof notifications, condition: ReturnType<typeof eq>) => {
  const result = await db.select({ count: sql<number>`count(*)::int` }).from(table).where(condition);
  return result[0]?.count || 0;
};

async function listPosts(viewerId?: string, includeHidden = false) {
  await (await import("@/lib/scheduled")).deliverDuePostMentions();
  const now = new Date();
  const filter = includeHidden ? undefined : and(lte(posts.publishAt, now), or(isNull(posts.expiresAt), gt(posts.expiresAt, now)));
  const rows = await db.select({ post: posts, author: users }).from(posts).innerJoin(users, eq(posts.authorId, users.id)).where(filter).orderBy(desc(posts.publishAt)).limit(40);
  return Promise.all(rows.map(async ({ post, author }) => {
    const [postComments, reactions] = await Promise.all([
      db.select({ comment: comments, user: users }).from(comments).innerJoin(users, eq(comments.userId, users.id)).where(eq(comments.postId, post.id)).orderBy(desc(comments.createdAt)).limit(20),
      db.select().from(postReactions).where(eq(postReactions.postId, post.id)),
    ]);
    return { ...post, author: compactUser(author), comments: postComments.reverse().map(({ comment, user }) => ({ ...comment, user: compactUser(user) })), reactions: reactions.map((item) => ({ userId: item.userId, emoji: item.emoji })), myReaction: reactions.find((item) => item.userId === viewerId)?.emoji || null };
  }));
}

async function inboxFor(userId: string) {
  const memberships = await db.select({ member: conversationMembers, conversation: conversations }).from(conversationMembers).innerJoin(conversations, eq(conversationMembers.conversationId, conversations.id)).where(eq(conversationMembers.userId, userId)).orderBy(desc(conversations.updatedAt)).limit(60);
  return Promise.all(memberships.map(async ({ member, conversation }) => {
    const [otherMembers, recent, unread] = await Promise.all([
      db.select({ member: conversationMembers, user: users }).from(conversationMembers).innerJoin(users, eq(conversationMembers.userId, users.id)).where(and(eq(conversationMembers.conversationId, conversation.id), ne(conversationMembers.userId, userId))).limit(30),
      db.select({ message: messages, sender: users }).from(messages).innerJoin(users, eq(messages.senderId, users.id)).where(and(eq(messages.conversationId, conversation.id), or(isNull(messages.scheduledAt), lte(messages.scheduledAt, new Date())))).orderBy(desc(messages.createdAt)).limit(1),
      db.select({ count: sql<number>`count(*)::int` }).from(messages).where(and(eq(messages.conversationId, conversation.id), ne(messages.senderId, userId), gt(messages.createdAt, member.lastReadAt), or(isNull(messages.scheduledAt), lte(messages.scheduledAt, new Date())))),
    ]);
    const other = otherMembers[0]?.user;
    return { ...conversation, name: conversation.kind === "group" ? conversation.name : other?.name || "Conversation", avatarUrl: conversation.kind === "group" ? conversation.avatarUrl : other?.avatarUrl || null, other: other ? compactUser(other) : null, memberRole: member.role, memberCount: otherMembers.length + 1, lastMessage: recent[0] ? { ...recent[0].message, sender: compactUser(recent[0].sender) } : null, unread: unread[0]?.count || 0 };
  }));
}

async function chatFor(conversationId: string, userId: string, adminRead = false) {
  const [conversation] = await db.select().from(conversations).where(eq(conversations.id, conversationId)).limit(1);
  if (!conversation) throw new ApiError("Conversation not found.", 404);
  const [membership] = await db.select().from(conversationMembers).where(and(eq(conversationMembers.conversationId, conversationId), eq(conversationMembers.userId, userId))).limit(1);
  if (!membership && !adminRead) throw new ApiError("You are not in this conversation.", 403);
  if (membership && !adminRead) await db.update(conversationMembers).set({ lastReadAt: new Date() }).where(and(eq(conversationMembers.conversationId, conversationId), eq(conversationMembers.userId, userId)));
  const [members, rows, savedDraft] = await Promise.all([
    db.select({ member: conversationMembers, user: users }).from(conversationMembers).innerJoin(users, eq(conversationMembers.userId, users.id)).where(eq(conversationMembers.conversationId, conversationId)).orderBy(asc(conversationMembers.joinedAt)),
    db.select({ message: messages, sender: users }).from(messages).innerJoin(users, eq(messages.senderId, users.id)).where(and(eq(messages.conversationId, conversationId), adminRead ? undefined : or(isNull(messages.scheduledAt), lte(messages.scheduledAt, new Date()), eq(messages.senderId, userId)))).orderBy(desc(messages.createdAt)).limit(120),
    db.select().from(drafts).where(and(eq(drafts.conversationId, conversationId), eq(drafts.userId, userId))).limit(1),
  ]);
  const ids = rows.map(({ message }) => message.id);
  const reactions = ids.length ? await db.select().from(messageReactions).where(inArray(messageReactions.messageId, ids)) : [];
  return { conversation, members: members.map(({ member, user }) => ({ ...compactUser(user), memberRole: member.role, lastReadAt: member.lastReadAt })), myRole: membership?.role || null, draft: savedDraft[0]?.body || "", messages: rows.reverse().map(({ message, sender }) => ({ ...message, body: message.deletedAt ? "" : message.body, attachmentUrl: message.deletedAt ? null : message.attachmentUrl, sender: compactUser(sender), reactions: reactions.filter((r) => r.messageId === message.id).map((r) => ({ userId: r.userId, emoji: r.emoji })) })) };
}

export async function GET(request: NextRequest) {
  try {
    await ensureSetup();
    const auth = await getAuth(request);
    const view = request.nextUrl.searchParams.get("view") || "bootstrap";
    const param = request.nextUrl.searchParams;
    if (view === "bootstrap") {
      const settings = await db.select().from(siteSettings);
      const [feed, notificationCount, requestsCount, inbox] = await Promise.all([
        listPosts(auth?.user.id),
        auth ? db.select({ count: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.userId, auth.user.id), isNull(notifications.readAt))) : Promise.resolve([{ count: 0 }]),
        auth ? countOf(confessions, eq(confessions.userId, auth.user.id)) : Promise.resolve(0),
        auth ? inboxFor(auth.user.id) : Promise.resolve([]),
      ]);
      return NextResponse.json({ viewer: auth ? publicUser(auth.user) : null, adminUnlocked: auth ? isAdmin(auth) : false, settings: Object.fromEntries(settings.map((s) => [s.key, s.value])), posts: feed, unreadNotifications: notificationCount[0]?.count || 0, requestCount: requestsCount, unreadMessages: inbox.reduce((total, item) => total + item.unread, 0) });
    }
    requireUser(auth);
    if (view === "cinema") return NextResponse.json({ posts: await listPosts(auth.user.id) });
    if (view === "requests") {
      const rows = await db.select().from(confessions).where(eq(confessions.userId, auth.user.id)).orderBy(desc(confessions.createdAt)).limit(100);
      const sentMessages = await countOf(messages, eq(messages.senderId, auth.user.id));
      return NextResponse.json({ requests: rows, sentMessages, activeSeconds: auth.user.activeSeconds });
    }
    if (view === "inbox") return NextResponse.json({ conversations: await inboxFor(auth.user.id) });
    if (view === "chat" || view === "adminChat") {
      const id = param.get("id");
      if (!isUuid(id)) throw new ApiError("Invalid conversation.");
      if (view === "adminChat") { requireAdmin(auth); await logActivity(auth.user.id, null, "admin_view_chat", id, auth.ipHash); }
      return NextResponse.json(await chatFor(id, auth.user.id, view === "adminChat"));
    }
    if (view === "profile") {
      const handle = username(param.get("username"));
      const [target] = await db.select().from(users).where(eq(users.username, handle)).limit(1);
      if (!target) throw new ApiError("Profile not found.", 404);
      const [followers, following, meFollowing, followersList, followingList] = await Promise.all([
        db.select({ count: sql<number>`count(*)::int` }).from(follows).where(eq(follows.followingId, target.id)),
        db.select({ count: sql<number>`count(*)::int` }).from(follows).where(eq(follows.followerId, target.id)),
        db.select().from(follows).where(and(eq(follows.followerId, auth.user.id), eq(follows.followingId, target.id))).limit(1),
        target.isPrivate && target.id !== auth.user.id ? Promise.resolve([]) : db.select({ user: users }).from(follows).innerJoin(users, eq(follows.followerId, users.id)).where(eq(follows.followingId, target.id)).limit(80),
        target.isPrivate && target.id !== auth.user.id ? Promise.resolve([]) : db.select({ user: users }).from(follows).innerJoin(users, eq(follows.followingId, users.id)).where(eq(follows.followerId, target.id)).limit(80),
      ]);
      return NextResponse.json({ profile: compactUser(target), followers: followers[0]?.count || 0, following: following[0]?.count || 0, isFollowing: !!meFollowing.length, followersList: followersList.map((row) => compactUser(row.user)), followingList: followingList.map((row) => compactUser(row.user)), isMe: target.id === auth.user.id });
    }
    if (view === "search") {
      const query = value(param.get("q"), 32).replace(/[%_\\]/g, "");
      if (!query) return NextResponse.json({ users: [] });
      const rows = await db.select().from(users).where(and(ilike(users.username, `%${query}%`), eq(users.restricted, false))).limit(20);
      return NextResponse.json({ users: rows.map(compactUser) });
    }
    if (view === "notifications") {
      const rows = await db.select().from(notifications).where(eq(notifications.userId, auth.user.id)).orderBy(desc(notifications.createdAt)).limit(70);
      return NextResponse.json({ notifications: rows });
    }
    if (view === "mine") {
      const [recent, deviceAccounts, ipAccounts] = await Promise.all([
        db.select().from(activities).where(eq(activities.targetId, auth.user.id)).orderBy(desc(activities.createdAt)).limit(20),
        auth.user.deviceHash ? db.select({ username: users.username }).from(users).where(eq(users.deviceHash, auth.user.deviceHash)) : Promise.resolve([]),
        auth.user.ipHash ? db.select({ username: users.username }).from(users).where(eq(users.ipHash, auth.user.ipHash)) : Promise.resolve([]),
      ]);
      return NextResponse.json({ activity: recent, deviceAccounts: deviceAccounts.map((u) => u.username), sharedNetworkCount: ipAccounts.length });
    }
    if (view === "invite") {
      const code = value(param.get("code"), 48);
      const [group] = await db.select().from(conversations).where(and(eq(conversations.inviteCode, code), eq(conversations.kind, "group"))).limit(1);
      if (!group) throw new ApiError("This invite link is invalid or expired.", 404);
      const members = await db.select({ count: sql<number>`count(*)::int` }).from(conversationMembers).where(eq(conversationMembers.conversationId, group.id));
      return NextResponse.json({ group: { id: group.id, name: group.name, description: group.description, avatarUrl: group.avatarUrl, memberCount: members[0]?.count || 0 } });
    }
    if (view === "adminUser") {
      requireAdmin(auth);
      const id = param.get("id");
      if (!isUuid(id)) throw new ApiError("Invalid account.");
      const [target] = await db.select().from(users).where(eq(users.id, id)).limit(1);
      if (!target) throw new ApiError("Account not found.", 404);
      const [history, userRequests, memberships, activeSessions, sameDevice, sameNetwork] = await Promise.all([
        db.select().from(activities).where(or(eq(activities.targetId, id), eq(activities.actorId, id))).orderBy(desc(activities.createdAt)).limit(300),
        db.select().from(confessions).where(eq(confessions.userId, id)).orderBy(desc(confessions.createdAt)).limit(100),
        db.select({ conversation: conversations, member: conversationMembers }).from(conversationMembers).innerJoin(conversations, eq(conversationMembers.conversationId, conversations.id)).where(and(eq(conversationMembers.userId, id), eq(conversations.kind, "group"))),
        db.select({ createdAt: sessions.createdAt, lastSeenAt: sessions.lastSeenAt, expiresAt: sessions.expiresAt, ipHash: sessions.ipHash }).from(sessions).where(and(eq(sessions.userId, id), gt(sessions.expiresAt, new Date()))).orderBy(desc(sessions.createdAt)).limit(20),
        target.deviceHash ? db.select({ id: users.id, username: users.username }).from(users).where(eq(users.deviceHash, target.deviceHash)) : Promise.resolve([]),
        target.ipHash ? db.select({ id: users.id, username: users.username }).from(users).where(eq(users.ipHash, target.ipHash)) : Promise.resolve([]),
      ]);
      await logActivity(auth.user.id, target.id, "admin_view_user", `@${target.username}`, auth.ipHash);
      return NextResponse.json({ user: { ...publicUser(target), ipSignal: target.ipHash?.slice(0, 12) || null, deviceSignal: target.deviceHash?.slice(0, 12) || null }, activity: history, requests: userRequests, groups: memberships.map(({ conversation, member }) => ({ id: conversation.id, name: conversation.name, role: member.role })), sessions: activeSessions.map((item) => ({ ...item, ipSignal: item.ipHash?.slice(0, 12) || null, ipHash: undefined })), sameDevice: sameDevice.filter((u) => u.id !== id), sameNetwork: sameNetwork.filter((u) => u.id !== id) });
    }
    if (view === "admin") {
      requireAdmin(auth);
      const [allUsers, allRequests, recentActivity, allGroups, allChats, allPosts, site, memberCounts, onlineSessions] = await Promise.all([
        db.select().from(users).orderBy(desc(users.createdAt)).limit(150),
        db.select({ request: confessions, user: users }).from(confessions).innerJoin(users, eq(confessions.userId, users.id)).orderBy(desc(confessions.createdAt)).limit(150),
        db.select().from(activities).orderBy(desc(activities.createdAt)).limit(100),
        db.select().from(conversations).where(eq(conversations.kind, "group")).orderBy(desc(conversations.createdAt)).limit(80),
        db.select().from(conversations).orderBy(desc(conversations.updatedAt)).limit(80),
        listPosts(auth.user.id, true),
        db.select().from(siteSettings),
        db.select({ userId: confessions.userId, count: sql<number>`count(*)::int` }).from(confessions).groupBy(confessions.userId),
        db.select({ userId: sessions.userId, count: sql<number>`count(*)::int` }).from(sessions).where(gt(sessions.expiresAt, new Date())).groupBy(sessions.userId),
      ]);
      const userMap = new Map(allUsers.map((u) => [u.id, u.username]));
      const requestsPerUser = new Map(memberCounts.map((r) => [r.userId, r.count]));
      const sessionsPerUser = new Map(onlineSessions.map((r) => [r.userId, r.count]));
      const enrichedGroups = await Promise.all(allGroups.map(async (group) => ({ ...group, memberCount: (await db.select({ count: sql<number>`count(*)::int` }).from(conversationMembers).where(eq(conversationMembers.conversationId, group.id)))[0]?.count || 0 })));
      return NextResponse.json({
        users: allUsers.map((user) => ({ ...publicUser(user), ipSignal: user.ipHash?.slice(0, 12) || null, deviceSignal: user.deviceHash?.slice(0, 12) || null, requestCount: requestsPerUser.get(user.id) || 0, sessionCount: sessionsPerUser.get(user.id) || 0 })),
        requests: allRequests.map(({ request: item, user }) => ({ ...item, user: compactUser(user) })),
        activity: recentActivity.map((item) => ({ ...item, actorUsername: item.actorId ? userMap.get(item.actorId) || "deleted" : "system", targetUsername: item.targetId ? userMap.get(item.targetId) || "deleted" : "—" })),
        groups: enrichedGroups,
        chats: allChats.map((chat) => ({ ...chat, creator: chat.createdBy ? userMap.get(chat.createdBy) || "deleted" : "—" })),
        posts: allPosts,
        settings: Object.fromEntries(site.map((s) => [s.key, s.value])),
        stats: { members: allUsers.length, pending: allRequests.filter((item) => item.request.status === "pending").length, approved: allRequests.filter((item) => item.request.status === "approved").length, admins: allUsers.filter((user) => user.role === "admin" || user.role === "owner").length, groups: allGroups.length, conversations: allChats.length },
      });
    }
    throw new ApiError("Unknown view.", 404);
  } catch (error) { return errorResponse(error); }
}
