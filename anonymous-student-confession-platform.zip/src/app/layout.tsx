import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "𓆩𝐂𝐈𝐍𝐄𝐌𝐀𓆪 • 𝐂𝐏𝐔 𝐔𝐍𝐓𝐎𝐋𝐃",
  description: "A private-feeling student space for Career Point University, Kota. Confess, connect, and share stories in Cinema. Independent student project.",
  applicationName: "Cinema · CPU Untold",
  openGraph: { title: "Cinema · CPU Untold", description: "Your confessions. Their stories. Our Cinema.", type: "website" },
};
export const viewport: Viewport = { themeColor: "#0d0c0e", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
