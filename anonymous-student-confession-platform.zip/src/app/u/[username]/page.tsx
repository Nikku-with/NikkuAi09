import type { Metadata } from "next";
import CinemaApp from "@/components/CinemaApp";

export async function generateMetadata({ params }: { params: Promise<{ username: string }> }): Promise<Metadata> {
  const { username } = await params;
  return { title: `@${username} · Cinema CPU Untold`, description: `View @${username}'s profile on Cinema CPU Untold.` };
}

export default async function ProfilePage({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  return <CinemaApp initialUsername={username} />;
}
