import CinemaApp from "@/components/CinemaApp";

export default function HomePage() {
  return <CinemaApp />;
}
