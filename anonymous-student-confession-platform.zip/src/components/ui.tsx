"use client";

import { useEffect, useRef, useState } from "react";
import { Heart, MessageCircle, MoreHorizontal, Send, Sparkles, Music2, Trash2 } from "lucide-react";
import type { CinemaPost, MiniUser } from "./types";

export async function getData<T>(view: string, params: Record<string, string> = {}): Promise<T> {
  const url = new URL("/api/portal", window.location.origin);
  url.searchParams.set("view", view);
  for (const [key, val] of Object.entries(params)) url.searchParams.set(key, val);
  const response = await fetch(url.toString(), { cache: "no-store" });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Could not load this page.");
  return data as T;
}
export async function postData<T = Record<string, unknown>>(path: string, payload: Record<string, unknown>): Promise<T> {
  const response = await fetch(path, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data as T;
}
export async function uploadFile(file: File) {
  const form = new FormData();
  form.append("file", file);
  const response = await fetch("/api/upload", { method: "POST", body: form, credentials: "same-origin" });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Upload failed.");
  return data as { url: string; mime: string };
}
export function formatTime(input?: string | null) {
  if (!input) return "—";
  const date = new Date(input);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
}
export function shortTime(input?: string | null) {
  if (!input) return "";
  const date = new Date(input);
  if (Number.isNaN(date.getTime())) return "";
  const diff = Date.now() - date.getTime();
  if (diff < 60_000) return "now";
  if (diff < 3600_000) return `${Math.floor(diff / 60_000)}m`;
  if (diff < 86400_000) return `${Math.floor(diff / 3600_000)}h`;
  if (diff < 7 * 86400_000) return `${Math.floor(diff / 86400_000)}d`;
  return date.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}
export function formatDuration(seconds: number) { return seconds >= 3600 ? `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m` : `${Math.floor(seconds / 60)}m`; }

export function Brand({ compact = false }: { compact?: boolean }) {
  return <div className={`brand ${compact ? "brand-compact" : ""}`} aria-label="Cinema CPU Untold">
    <span className="brand-symbol"><span className="brand-c">C</span><span className="brand-heart">♥</span><Send className="brand-plane" size={16} fill="currentColor" strokeWidth={1.8} /></span>
    <span className="brand-words"><strong>CINEMA<span className="brand-spark">✦</span></strong><small>CPU UNTOLD</small></span>
  </div>;
}
export function Avatar({ user, size = 42, className = "" }: { user?: Partial<MiniUser> | null; size?: number; className?: string }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [user?.avatarUrl]);
  const seed = user?.username || user?.name || "C";
  const colors = ["#c16c7d", "#82677f", "#9a8178", "#ba7c67", "#795d70", "#a66778"];
  const color = colors[seed.split("").reduce((n, ch) => n + ch.charCodeAt(0), 0) % colors.length];
  return <span className={`avatar ${className}`} style={{ width: size, height: size, minWidth: size, background: color }}>
    {user?.avatarUrl && !failed ? <img src={user.avatarUrl} alt={user.name || "Profile"} onError={() => setFailed(true)} /> : <span>{(user?.name || user?.username || "C").charAt(0).toUpperCase()}</span>}
  </span>;
}
export function RichText({ text, onProfile }: { text: string; onProfile: (username: string) => void }) {
  return <>{text.split(/(@[a-z0-9_.]{3,32}|https?:\/\/[^\s]+)/gi).map((piece, index) => {
    if (/^@[a-z0-9_.]{3,32}$/i.test(piece)) return <button type="button" className="inline-mention" onClick={() => onProfile(piece.slice(1))} key={index}>{piece}</button>;
    if (/^https?:\/\//i.test(piece)) return <a className="inline-link" href={piece} target="_blank" rel="noopener noreferrer" key={index}>{piece}</a>;
    return <span key={index}>{piece}</span>;
  })}</>;
}
export function StatusBadge({ status }: { status: string }) {
  return <span className={`status-badge status-${status}`}>{status === "approved" ? "Approved" : status === "declined" ? "Declined" : status === "pending" ? "Pending" : status}</span>;
}

const emojis = ["❤️", "😂", "🥹", "😮", "🔥", "👏", "💌", "👍"];
export function PostCard({ post, viewerId, onAction, onProfile, onNeedAuth, canManage = false }: {
  post: CinemaPost; viewerId?: string; onAction: (action: string, payload: Record<string, unknown>, success?: string) => Promise<unknown | null>;
  onProfile: (username: string) => void; onNeedAuth: () => void; canManage?: boolean;
}) {
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [comment, setComment] = useState("");
  const [pickerOpen, setPickerOpen] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const startedRef = useRef(false);
  async function react(emoji: string) {
    if (!viewerId) return onNeedAuth();
    setPickerOpen(false);
    await onAction("reactPost", { postId: post.id, emoji });
  }
  async function submitComment(event: React.FormEvent) {
    event.preventDefault();
    if (!viewerId) return onNeedAuth();
    if (!comment.trim()) return;
    const result = await onAction("commentPost", { postId: post.id, text: comment }, "Comment posted");
    if (result) setComment("");
  }
  return <article className="post-card" id={`post-${post.id}`}>
    <div className="post-topline"><div className="post-author"><Avatar user={post.author} size={43} /><div><button className="author-name" onClick={() => onProfile(post.author.username)}>{post.author.name} <span className="verified-dot">✦</span></button><p>@{post.author.username} <span>·</span> {shortTime(post.publishAt)}</p></div></div><div className="post-menu-area">{post.sourceConfessionId ? <span className="post-editorial">FROM A CONFESSION</span> : <span className="post-editorial">CINEMA ORIGINAL</span>}{canManage && <button className="icon-button subtle" title="Delete post" onClick={() => { if (window.confirm("Remove this Cinema post?")) void onAction("deletePost", { id: post.id }, "Post removed"); }}><Trash2 size={16} /></button>}</div></div>
    <p className="post-caption"><RichText text={post.caption} onProfile={onProfile} /></p>
    {post.imageUrl && <div className={`post-image filter-${post.filter}`}><img src={post.imageUrl} alt="Cinema post visual" /></div>}
    {post.audioUrl && <div className="post-audio"><span className="audio-icon"><Music2 size={17} /></span><div className="audio-meta"><strong>Soundtrack attached</strong><small>{post.audioDuration}s clip · starts at {post.audioStart}s</small></div><audio ref={audioRef} src={post.audioUrl} controls preload="none" onPlay={() => { if (!startedRef.current && audioRef.current) { audioRef.current.currentTime = post.audioStart; startedRef.current = true; } }} onTimeUpdate={() => { if (audioRef.current && audioRef.current.currentTime >= post.audioStart + post.audioDuration) { audioRef.current.pause(); audioRef.current.currentTime = post.audioStart; startedRef.current = false; } }} /></div>}
    <div className="post-actions"><div className="reaction-holder"><button className={`post-action ${post.myReaction ? "liked" : ""}`} onClick={() => void react(post.myReaction || "❤️")}><Heart size={19} fill={post.myReaction ? "currentColor" : "none"} /> {post.reactions.length ? post.reactions.length : "Like"}</button><button className="tiny-chevron" aria-label="Choose reaction" onClick={() => setPickerOpen(!pickerOpen)}>⌄</button>{pickerOpen && <div className="emoji-popup">{emojis.map((emoji) => <button key={emoji} onClick={() => void react(emoji)}>{emoji}</button>)}</div>}</div><button className="post-action" onClick={() => setCommentsOpen(!commentsOpen)}><MessageCircle size={19} /> {post.comments.length ? post.comments.length : "Comment"}</button><span className="post-actions-end"><Sparkles size={14} /> STORIES LIVE HERE</span></div>
    {commentsOpen && <div className="comments-area"><div className="comments-heading">The conversation <span>{post.comments.length} replies</span></div>{post.comments.length ? post.comments.map((item) => <div className="comment" key={item.id}><Avatar user={item.user} size={31} /><div className="comment-body"><div><button onClick={() => onProfile(item.user.username)}>@{item.user.username}</button><span>{shortTime(item.createdAt)}</span></div><p><RichText text={item.body} onProfile={onProfile} /></p></div>{(item.userId === viewerId || canManage) && <button title="Delete comment" className="icon-button subtle" onClick={() => void onAction("deleteComment", { commentId: item.id }, "Comment removed")}><MoreHorizontal size={16} /></button>}</div>) : <p className="muted empty-comments">Be the first to add a thought.</p>}<form className="comment-form" onSubmit={submitComment}><input value={comment} onChange={(event) => setComment(event.target.value)} placeholder={viewerId ? "Leave a little thought..." : "Sign in to comment"} maxLength={1000} /><button type="submit" aria-label="Send comment"><Send size={17} /></button></form></div>}
  </article>;
}
