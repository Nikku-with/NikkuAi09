export type MiniUser = {
  id: string; username: string; name: string; nickname: string | null; avatarUrl: string | null;
  bio: string; branch: string | null; semester: string | null; isPrivate: boolean;
  role: string; theme: string; contactHandle: string | null;
};
export type Viewer = MiniUser & {
  inviteSetting: string; notificationsMuted: boolean; restricted: boolean;
  activeSeconds: number; lastLoginAt: string | null; createdAt: string;
};
export type Reaction = { userId: string; emoji: string };
export type PostComment = { id: string; postId: string; userId: string; body: string; createdAt: string; user: MiniUser };
export type CinemaPost = {
  id: string; authorId: string; caption: string; imageUrl: string | null; audioUrl: string | null;
  audioStart: number; audioDuration: number; filter: string; sourceConfessionId: string | null;
  publishAt: string; expiresAt: string | null; createdAt: string; author: MiniUser;
  comments: PostComment[]; reactions: Reaction[]; myReaction: string | null;
};
export type Confession = {
  id: string; userId: string; subject: string; content: string; contact: string | null;
  status: string; adminNote: string | null; seenAt: string | null; createdAt: string; updatedAt: string;
};
export type Conversation = {
  id: string; kind: string; name: string; description: string | null; avatarUrl: string | null;
  inviteCode: string | null; createdBy: string | null; createdAt: string; updatedAt: string;
  other: MiniUser | null; memberRole: string; memberCount: number; unread: number;
  lastMessage: (ChatMessage & { sender: MiniUser }) | null;
};
export type ChatMessage = {
  id: string; conversationId: string; senderId: string; body: string; attachmentUrl: string | null;
  replyToId: string | null; forwardedFromId: string | null; scheduledAt: string | null;
  createdAt: string; deletedAt: string | null; sender: MiniUser; reactions: Reaction[];
};
export type Chat = {
  conversation: { id: string; kind: string; name: string | null; description: string | null; avatarUrl: string | null; inviteCode: string | null; createdBy: string | null };
  members: (MiniUser & { memberRole: string; lastReadAt: string })[]; myRole: string | null; draft: string; messages: ChatMessage[];
};
export type AppNotification = { id: string; userId: string; type: string; title: string; body: string; link: string | null; readAt: string | null; createdAt: string };
export type ProfileData = { profile: MiniUser; followers: number; following: number; isFollowing: boolean; followersList: MiniUser[]; followingList: MiniUser[]; isMe: boolean };
export type Activity = { id: string; actorId: string | null; targetId: string | null; action: string; detail: string; ipHash: string | null; createdAt: string; actorUsername?: string; targetUsername?: string };
export type AdminUser = Viewer & { ipSignal: string | null; deviceSignal: string | null; requestCount: number; sessionCount: number };
export type AdminRequest = Confession & { user: MiniUser };
export type AdminGroup = { id: string; name: string | null; description: string | null; avatarUrl: string | null; inviteCode: string | null; createdBy: string | null; createdAt: string; memberCount: number };
export type AdminChat = { id: string; kind: string; name: string | null; creator: string; createdAt: string; updatedAt: string };
export type AdminData = {
  users: AdminUser[]; requests: AdminRequest[]; activity: Activity[]; groups: AdminGroup[];
  chats: AdminChat[]; posts: CinemaPost[]; settings: Record<string, string>;
  stats: { members: number; pending: number; approved: number; admins: number; groups: number; conversations: number };
};
export type Bootstrap = { viewer: Viewer | null; adminUnlocked: boolean; settings: Record<string, string>; posts: CinemaPost[]; unreadNotifications: number; requestCount: number; unreadMessages: number };
