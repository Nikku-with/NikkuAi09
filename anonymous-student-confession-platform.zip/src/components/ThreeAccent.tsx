"use client";

import { useMemo } from "react";
import { Canvas } from "@react-three/fiber";
import { Float, Sparkles } from "@react-three/drei";
import { BufferGeometry, DoubleSide, Float32BufferAttribute } from "three";

function PaperPlane() {
  const { left, right } = useMemo(() => {
    const make = (vertices: number[]) => {
      const geometry = new BufferGeometry();
      geometry.setAttribute("position", new Float32BufferAttribute(vertices, 3));
      geometry.computeVertexNormals();
      return geometry;
    };
    return {
      left: make([1.5, 0.15, 0, -1.1, 0.78, 0, -0.3, 0.02, 0.35]),
      right: make([1.5, 0.15, 0, -0.3, 0.02, 0.35, -0.95, -0.72, 0]),
    };
  }, []);
  return (
    <Float speed={1.6} rotationIntensity={0.18} floatIntensity={0.55}>
      <group rotation={[0.18, -0.38, -0.13]} scale={0.72}>
        <mesh geometry={left}><meshStandardMaterial color="#f5a8b5" metalness={0.2} roughness={0.35} side={DoubleSide} /></mesh>
        <mesh geometry={right}><meshStandardMaterial color="#b84c69" metalness={0.18} roughness={0.42} side={DoubleSide} /></mesh>
        <mesh position={[-0.62, -0.3, 0.02]} rotation={[0, 0, -0.3]}><boxGeometry args={[0.65, 0.018, 0.018]} /><meshStandardMaterial color="#f8c2c5" /></mesh>
      </group>
    </Float>
  );
}

export default function ThreeAccent() {
  return (
    <Canvas camera={{ position: [0, 0, 5], fov: 38 }} dpr={[1, 1.5]} gl={{ alpha: true, antialias: true }} style={{ pointerEvents: "none" }}>
      <ambientLight intensity={1.45} />
      <pointLight position={[3, 3, 4]} intensity={16} color="#ffadbf" />
      <PaperPlane />
      <Sparkles count={17} size={2} scale={[5, 3, 2]} speed={0.25} color="#e7a6ad" opacity={0.6} />
    </Canvas>
  );
}
