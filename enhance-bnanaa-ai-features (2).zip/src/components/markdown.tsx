"use client";

import { useState, type ReactNode } from "react";
import { copyText, downloadFile } from "@/lib/client-utils";
import Widget, { type CodeBlockData } from "./widgets";

/* ---------- Code block with working Copy + Download ---------- */
export function CodeBlock({ block }: { block: CodeBlockData }) {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  return (
    <div className="my-2.5 rounded-xl overflow-hidden border border-zinc-700/80 bg-[#0d0d10]">
      <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border-b border-zinc-800">
        <span className="flex gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
        </span>
        <span className="text-[11px] font-mono text-zinc-400 truncate">
          {block.filename}
        </span>
        <span className="text-[10px] px-1.5 rounded bg-zinc-800 text-zinc-500">
          {block.language}
        </span>
        <div className="ml-auto flex gap-1.5">
          <button
            onClick={async () => {
              if (await copyText(block.content)) {
                setCopied(true);
                setTimeout(() => setCopied(false), 1600);
              }
            }}
            className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all active:scale-95 ${
              copied
                ? "bg-emerald-500/20 text-emerald-300"
                : "bg-zinc-800 text-zinc-300 hover:bg-zinc-700"
            }`}
          >
            {copied ? "✓ Copied" : "📋 Copy"}
          </button>
          <button
            onClick={() => {
              if (downloadFile(block.filename, block.content)) {
                setSaved(true);
                setTimeout(() => setSaved(false), 1600);
              }
            }}
            className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all active:scale-95 ${
              saved
                ? "bg-emerald-500/20 text-emerald-300"
                : "bg-zinc-800 text-zinc-300 hover:bg-zinc-700"
            }`}
          >
            {saved ? "✓ Saved" : "⬇ Download"}
          </button>
        </div>
      </div>
      <pre className="p-3 overflow-x-auto scroll-thin text-[12.5px] leading-relaxed text-zinc-200 font-mono max-h-96 overflow-y-auto">
        <code>{block.content}</code>
      </pre>
    </div>
  );
}

/* ---------- inline markdown ---------- */
function inline(text: string): ReactNode[] {
  const out: ReactNode[] = [];
  // **bold**, `code`, [text](url)
  const rx = /(\*\*([^*]+)\*\*)|(`([^`]+)`)|(\[([^\]]+)\]\((https?:\/\/[^)]+)\))/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = rx.exec(text)) !== null) {
    if (m.index > last) out.push(text.slice(last, m.index));
    if (m[2])
      out.push(
        <strong key={k++} className="font-bold text-zinc-50">
          {m[2]}
        </strong>
      );
    else if (m[4])
      out.push(
        <code
          key={k++}
          className="px-1 py-0.5 rounded bg-zinc-800 text-yellow-300 font-mono text-[0.9em]"
        >
          {m[4]}
        </code>
      );
    else if (m[6])
      out.push(
        <a
          key={k++}
          href={m[7]}
          target="_blank"
          rel="noopener noreferrer"
          className="text-yellow-400 underline underline-offset-2 hover:text-yellow-300"
        >
          {m[6]}
        </a>
      );
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function MdText({ text }: { text: string }) {
  const lines = text.split("\n");
  const out: ReactNode[] = [];
  let k = 0;
  for (const line of lines) {
    const t = line.trimEnd();
    if (!t.trim()) continue;
    if (t.startsWith("### "))
      out.push(
        <h4 key={k++} className="text-[14px] font-bold text-yellow-200 mt-3 mb-1">
          {inline(t.slice(4))}
        </h4>
      );
    else if (t.startsWith("## "))
      out.push(
        <h3 key={k++} className="text-[16px] font-extrabold text-yellow-300 mt-3 mb-1">
          {inline(t.slice(3))}
        </h3>
      );
    else if (t.startsWith("# "))
      out.push(
        <h2 key={k++} className="text-[18px] font-black text-yellow-300 mt-3 mb-1.5">
          {inline(t.slice(2))}
        </h2>
      );
    else if (/^[-*]\s+/.test(t))
      out.push(
        <div key={k++} className="flex gap-2 pl-1 my-0.5">
          <span className="text-yellow-500 shrink-0">•</span>
          <span>{inline(t.replace(/^[-*]\s+/, ""))}</span>
        </div>
      );
    else if (/^\d+\.\s+/.test(t)) {
      const num = t.match(/^(\d+)\./)?.[1];
      out.push(
        <div key={k++} className="flex gap-2 pl-1 my-0.5">
          <span className="text-yellow-500 font-bold shrink-0">{num}.</span>
          <span>{inline(t.replace(/^\d+\.\s+/, ""))}</span>
        </div>
      );
    } else
      out.push(
        <p key={k++} className="my-1">
          {inline(t)}
        </p>
      );
  }
  return <>{out}</>;
}

/* ---------- Segment parser: text | code | widget ---------- */
type Segment =
  | { type: "text"; text: string }
  | { type: "code"; block: CodeBlockData }
  | { type: "widget"; kind: string; params: string };

export function parseSegments(content: string): {
  segments: Segment[];
  codeBlocks: CodeBlockData[];
} {
  const segments: Segment[] = [];
  const codeBlocks: CodeBlockData[] = [];
  const codeRx = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)(```|$)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let fileIdx = 1;

  const pushText = (text: string) => {
    // split out widgets from text
    const wrx = /\[WIDGET:([\w_]+):([^\]]*)\]|\[WIDGET:([\w_]+)\]/g;
    let l = 0;
    let wm: RegExpExecArray | null;
    while ((wm = wrx.exec(text)) !== null) {
      if (wm.index > l) {
        const t = text.slice(l, wm.index);
        if (t.trim()) segments.push({ type: "text", text: t });
      }
      segments.push({
        type: "widget",
        kind: wm[1] || wm[3],
        params: wm[2] || "",
      });
      l = wm.index + wm[0].length;
    }
    if (l < text.length) {
      const t = text.slice(l);
      if (t.trim()) segments.push({ type: "text", text: t });
    }
  };

  while ((m = codeRx.exec(content)) !== null) {
    if (m.index > last) pushText(content.slice(last, m.index));
    let lang = m[1] || "text";
    let fname = (m[2] || "").trim();
    const code = (m[3] || "").trimEnd();
    const lm: Record<string, string> = {
      js: "javascript",
      ts: "typescript",
      py: "python",
      jsx: "javascript",
      tsx: "typescript",
    };
    lang = lm[lang] || lang;
    if (!fname) {
      const em: Record<string, string> = {
        javascript: "js",
        typescript: "ts",
        python: "py",
        html: "html",
        css: "css",
        json: "json",
        bash: "sh",
      };
      fname = `file${fileIdx++}.${em[lang] || "txt"}`;
    }
    const block = { filename: fname, language: lang, content: code };
    codeBlocks.push(block);
    segments.push({ type: "code", block });
    last = m.index + m[0].length;
  }
  if (last < content.length) pushText(content.slice(last));
  return { segments, codeBlocks };
}

export default function Markdown({
  content,
  streaming = false,
}: {
  content: string;
  streaming?: boolean;
}) {
  const { segments, codeBlocks } = parseSegments(content);
  return (
    <div className="text-[13.5px] leading-relaxed text-zinc-200">
      {segments.map((s, i) => {
        if (s.type === "code") return <CodeBlock key={i} block={s.block} />;
        if (s.type === "widget")
          return streaming ? (
            <div
              key={i}
              className="my-2 h-10 rounded-xl bg-zinc-800/60 animate-shimmer-bg"
            />
          ) : (
            <Widget key={i} kind={s.kind} params={s.params} codeBlocks={codeBlocks} />
          );
        return <MdText key={i} text={s.text} />;
      })}
    </div>
  );
}
