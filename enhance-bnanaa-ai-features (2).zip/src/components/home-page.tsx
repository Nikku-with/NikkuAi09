"use client";

import { useAgent } from "@/components/agent-context";
import { TOOL_COUNT, TOOLS_VERIFIED, TOOL_CATEGORIES } from "@/lib/tools";

function FeatureCard({
  icon,
  title,
  desc,
  color,
}: {
  icon: string;
  title: string;
  desc: string;
  color: string;
}) {
  return (
    <div
      className="group rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5 hover:border-yellow-500/40 hover:bg-zinc-900 transition-all hover:shadow-[0_0_24px_rgba(250,204,21,0.1)]"
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl mb-3"
        style={{ background: `${color}15`, boxShadow: `0 0 16px ${color}25` }}
      >
        {icon}
      </div>
      <h3 className="text-[15px] font-bold text-zinc-100 mb-1">{title}</h3>
      <p className="text-[12.5px] text-zinc-400 leading-relaxed">{desc}</p>
    </div>
  );
}

export default function HomePage() {
  const ctx = useAgent();
  const { createSession, setActiveTab, setShowSettings, hasKey } = ctx;

  const startChat = async (withSearch = false, prompt = "") => {
    const s = await createSession();
    if (s) {
      setActiveTab("chat");
      if (prompt) {
        // Small delay to let the UI switch tabs
        setTimeout(() => {
          // Dispatch a custom event the chat panel can listen to
          window.dispatchEvent(
            new CustomEvent("banana-prefill", {
              detail: { prompt, search: withSearch },
            })
          );
        }, 150);
      }
    }
  };

  const features = [
    {
      icon: "🧠",
      title: "Deep Reasoning Agent",
      desc: "Multi-phase thinking card shows reasoning, writing, coding and optimizing live.",
      color: "#facc15",
    },
    {
      icon: "🌐",
      title: "Live Web Search",
      desc: "Real DuckDuckGo search with scrolling source links — not fake previews.",
      color: "#34d399",
    },
    {
      icon: "🕐",
      title: "Realtime Clock",
      desc: "AI always knows the current date and time in IST + UTC.",
      color: "#a78bfa",
    },
    {
      icon: "☑️",
      title: "Multi-select Widgets",
      desc: "Pick multiple options, type your own, then hit Launch — one-click response.",
      color: "#fb923c",
    },
    {
      icon: "📋",
      title: "Copy & Download",
      desc: "Every code block, file and response gets working Copy + Download buttons.",
      color: "#60a5fa",
    },
    {
      icon: "🧰",
      title: `${TOOL_COUNT} Verified Tools`,
      desc: `${TOOL_CATEGORIES.length} categories from code generation to DevOps to AI.`,
      color: "#f472b6",
    },
  ];

  const starters = [
    { icon: "🌐", text: "Search the web: latest AI news", search: true },
    { icon: "🕐", text: "What time is it right now?" },
    { icon: "🏗️", text: "Build me a landing page for a startup" },
    { icon: "🧮", text: "Explain binary search like I'm 10" },
    { icon: "🎮", text: "Create a tic-tac-toe game" },
    { icon: "🔍", text: "Search: best React hooks practices 2026", search: true },
  ];

  return (
    <div className="min-h-full overflow-y-auto scroll-thin bg-gradient-to-b from-zinc-950 via-zinc-950 to-black">
      {/* Hero */}
      <div className="max-w-5xl mx-auto px-4 pt-12 pb-8 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-yellow-500/30 bg-yellow-500/10 text-[11px] font-bold text-yellow-300 mb-5">
          {TOOLS_VERIFIED ? `✅ ${TOOL_COUNT}/100 tools verified` : "⚠️ tool check"}
          <span className="text-yellow-500/50">·</span>
          <span>Next.js + PostgreSQL</span>
        </div>
        <div className="text-7xl mb-4 animate-float inline-block">🍌</div>
        <h1 className="text-4xl sm:text-5xl font-black tracking-tight mb-3">
          <span className="bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-300 bg-clip-text text-transparent">
            BANANA
          </span>{" "}
          <span className="text-zinc-100">AGENT</span>
        </h1>
        <p className="text-[15px] text-zinc-400 max-w-xl mx-auto leading-relaxed">
          Autonomous AI coding agent with live web search, realtime clock, multi-select
          widgets, and working copy & download on everything.
        </p>

        {/* Primary CTAs */}
        <div className="flex items-center justify-center gap-2.5 mt-7 flex-wrap">
          <button
            onClick={() => startChat()}
            className="px-6 py-3 rounded-xl text-[14px] font-black bg-gradient-to-r from-yellow-400 to-amber-500 text-zinc-900 hover:brightness-110 active:scale-95 transition-all shadow-[0_0_24px_rgba(250,204,21,0.35)]"
          >
            🚀 Start Chatting
          </button>
          <button
            onClick={() => startChat(true, "Search the web for: latest AI developments")}
            className="px-6 py-3 rounded-xl text-[14px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/25 active:scale-95 transition-all"
          >
            🌐 Try Web Search
          </button>
          {!hasKey && (
            <button
              onClick={() => setShowSettings(true)}
              className="px-6 py-3 rounded-xl text-[14px] font-bold bg-zinc-900 text-zinc-300 border border-zinc-700 hover:border-zinc-500 active:scale-95 transition-all"
            >
              ⚙️ Add API Key
            </button>
          )}
        </div>

        {/* Starter prompts */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 mt-10 max-w-3xl mx-auto">
          {starters.map((s, i) => (
            <button
              key={i}
              onClick={() => startChat(Boolean(s.search), s.text)}
              className="flex items-start gap-2.5 rounded-xl border border-zinc-800 bg-zinc-900/60 px-3.5 py-3 text-left text-[12.5px] text-zinc-300 hover:border-yellow-500/40 hover:bg-zinc-900 transition-all active:scale-[0.98]"
            >
              <span className="text-lg shrink-0">{s.icon}</span>
              <span className="flex-1">{s.text}</span>
              {s.search && (
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 font-bold shrink-0">
                  SEARCH
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Features */}
      <div className="max-w-5xl mx-auto px-4 pb-12">
        <h2 className="text-xl font-black text-zinc-100 mb-5 text-center">
          Everything you need, nothing you don't
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {features.map((f, i) => (
            <FeatureCard key={i} {...f} />
          ))}
        </div>
      </div>

      {/* Tool categories */}
      <div className="max-w-5xl mx-auto px-4 pb-16">
        <h2 className="text-xl font-black text-zinc-100 mb-5 text-center">
          {TOOL_COUNT} tools across {TOOL_CATEGORIES.length} categories
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {TOOL_CATEGORIES.map((c, i) => (
            <div
              key={i}
              className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4 hover:border-zinc-700 transition-colors"
            >
              <div className="flex items-center gap-2 mb-2">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ background: c.color }}
                />
                <span className="text-[12.5px] font-bold text-zinc-100">{c.name}</span>
                <span className="ml-auto text-[10px] text-zinc-500 font-mono">
                  {c.tools.length}
                </span>
              </div>
              <div className="flex flex-wrap gap-1">
                {c.tools.slice(0, 5).map((t, j) => (
                  <span
                    key={j}
                    className="text-[10.5px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400"
                  >
                    {t.name}
                  </span>
                ))}
                {c.tools.length > 5 && (
                  <span className="text-[10.5px] px-1.5 py-0.5 text-zinc-500">
                    +{c.tools.length - 5} more
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-zinc-800/80 py-6 text-center text-[11px] text-zinc-500">
        🍌 Banana Agent · Built with Next.js, Drizzle ORM & PostgreSQL
      </div>
    </div>
  );
}
