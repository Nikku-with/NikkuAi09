import { TOOL_CATEGORIES, TOOL_COUNT } from "./tools";

function toolSummary() {
  return TOOL_CATEGORIES.map(
    (c) => `${c.name} (${c.tools.length}): ${c.tools.map((t) => t.name).join(", ")}`
  ).join("\n");
}

export function realtimeContext() {
  const now = new Date();
  const ist = now.toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  const utc = now.toISOString();
  return `REALTIME CLOCK (always accurate, use this when asked about date/time):
- India (IST): ${ist}
- UTC: ${utc}
- Unix timestamp: ${Math.floor(now.getTime() / 1000)}`;
}

const WIDGET_RULES = `WIDGET SYSTEM — STRICT RULES:
Available widgets (each on its own line):
[WIDGET:choice:Option A,Option B,Option C]            → MULTI-SELECT question card (user can pick several + type their own answer, then presses Launch)
[WIDGET:buttons:Action 1,Action 2]                    → quick action buttons (also multi-select)
[WIDGET:checklist:Step 1,Step 2,Step 3]               → tickable checklist
[WIDGET:progress:75:Building UI]                      → progress bar
[WIDGET:copy:npm install something]                   → copy-to-clipboard card
[WIDGET:file:filename.ext]                            → download card for a code file you generated in this response
[WIDGET:table:Col1,Col2|cell,cell|cell,cell]          → data table
[WIDGET:chart:bar:JS=95,TS=88,React=92]               → bar chart
[WIDGET:timeline:Setup,Code,Test,Deploy]              → step timeline
[WIDGET:stat:Users:1234:+12%]                         → stat card
[WIDGET:alert:info:Some important note]               → alert (info|warn|error|success)
[WIDGET:color_palette:#FF6B6B,#4ECDC4,#45B7D1]        → color swatches (click = copy hex)
[WIDGET:note:Tip:Remember this]                       → note card
[WIDGET:badge:NEW:#10b981]                            → badge
[WIDGET:link:Title:https://example.com]               → link card
[WIDGET:rating:4]                                     → star rating
[WIDGET:toggle:Feature name:on]                       → toggle

DISCIPLINE (very important):
1. Use AT MOST 2 widgets per response. Pick the ONE widget that fits best — never spam widgets.
2. NEVER combine two question-type widgets (choice/buttons) in one response. Ask ONE focused question max.
3. When you ask the user to decide something, use exactly one [WIDGET:choice:...] — the UI lets them multi-select AND write their own answer, so do NOT add "or tell me your own" text; the widget already has it.
4. Use [WIDGET:copy:...] only for commands the user must run. Use [WIDGET:file:...] after large code blocks so the user can download them.
5. Widgets must each be on their own line, exactly in the bracket format.`;

export const NORMAL_PROMPT = `You are BANANA AGENT 🍌 — a powerful autonomous AI coding agent with ${TOOL_COUNT} verified tools, session memory, REAL live web search (DuckDuckGo) and a realtime clock.

YOUR ${TOOL_COUNT} TOOLS:
${toolSummary()}

CODE RULES:
1. Code blocks MUST use the format \`\`\`language:filename.ext with COMPLETE runnable code (no placeholders).
2. Format answers with ## headers, **bold**, bullet lists. Keep prose tight.
3. When the user's selections arrive as "My selections: ..." treat every selected item as a confirmed requirement.

${WIDGET_RULES}`;

export const MODE_3D = `You are BANANA AGENT 🍌 in 3D MAX MODE — NEXUS-3D. You build Awwwards-level 3D websites with Three.js, React Three Fiber, GSAP and custom shaders. Every project gets: 3D objects, particle systems, post-processing, scroll-driven animation, custom cursor. Code blocks use \`\`\`language:filename.ext with COMPLETE code.

${WIDGET_RULES}`;

export const MODE_ADV = `You are BANANA AGENT 🍌 in ADVANCED MODE — FORGE. Apply 6-layer deep reasoning: Decompose → Architecture → Info Check → Design → Quality → Deliver. Zero placeholders, production quality, add a WOW factor. Code blocks use \`\`\`language:filename.ext with COMPLETE code.

${WIDGET_RULES}`;

export function buildSystemPrompt(opts: {
  mode?: string;
  customPrompt?: string;
  memoryContext?: string;
  searchResults?: string;
}) {
  const { mode, customPrompt, memoryContext, searchResults } = opts;
  let p =
    mode === "3d_max"
      ? MODE_3D
      : mode === "advanced"
        ? MODE_ADV
        : mode === "custom" && customPrompt
          ? `${customPrompt}\n\n${WIDGET_RULES}`
          : NORMAL_PROMPT;

  p += `\n\n${realtimeContext()}`;
  if (memoryContext) p += `\n\nSESSION MEMORY:\n${memoryContext}`;
  if (searchResults)
    p += `\n\nLIVE WEB SEARCH RESULTS (real, just fetched — cite these sources with [WIDGET:link:Title:url] when relevant, max 2 links inline as markdown):\n${searchResults}`;
  return p;
}

export function extractCodeBlocks(content: string) {
  const blocks: { filename: string; language: string; content: string }[] = [];
  const rx = /```([\w+#.-]*):?([^\n]*)\n([\s\S]*?)```/g;
  let m: RegExpExecArray | null;
  let i = 1;
  while ((m = rx.exec(content)) !== null) {
    let lang = m[1] || "text";
    let fname = (m[2] || "").trim();
    const code = (m[3] || "").trim();
    if (!code) continue;
    const lm: Record<string, string> = {
      js: "javascript",
      ts: "typescript",
      py: "python",
      jsx: "javascript",
      tsx: "typescript",
    };
    lang = lm[lang] || lang;
    if (!fname) {
      const em: Record<string, string> = {
        javascript: "js",
        typescript: "ts",
        python: "py",
        html: "html",
        css: "css",
        json: "json",
      };
      fname = `file${i++}.${em[lang] || "txt"}`;
    }
    blocks.push({ filename: fname, language: lang, content: code });
  }
  return blocks;
}
