export const dynamic = "force-dynamic";
export const maxDuration = 30;

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  domain: string;
}

function decodeEntities(s: string) {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ")
    .trim();
}

function resolveDdgUrl(href: string): string {
  try {
    let h = href;
    if (h.startsWith("//")) h = "https:" + h;
    const u = new URL(h, "https://duckduckgo.com");
    const uddg = u.searchParams.get("uddg");
    if (uddg) return decodeURIComponent(uddg);
    return h;
  } catch {
    return href;
  }
}

async function ddgSearch(query: string): Promise<SearchResult[]> {
  const results: SearchResult[] = [];
  const endpoints = [
    `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`,
    `https://lite.duckduckgo.com/lite/?q=${encodeURIComponent(query)}`,
  ];
  for (const endpoint of endpoints) {
    try {
      const r = await fetch(endpoint, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
          Accept: "text/html",
        },
        signal: AbortSignal.timeout(12000),
      });
      if (!r.ok) continue;
      const html = await r.text();

      // html.duckduckgo.com format
      const linkRx =
        /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
      const snipRx =
        /<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>|<td[^>]*class="result-snippet"[^>]*>([\s\S]*?)<\/td>/g;
      const snippets: string[] = [];
      let sm: RegExpExecArray | null;
      while ((sm = snipRx.exec(html)) !== null)
        snippets.push(decodeEntities(sm[1] || sm[2] || ""));

      let m: RegExpExecArray | null;
      let i = 0;
      while ((m = linkRx.exec(html)) !== null && results.length < 10) {
        const url = resolveDdgUrl(m[1]);
        const title = decodeEntities(m[2]);
        if (!title || !url.startsWith("http")) continue;
        let domain = "";
        try {
          domain = new URL(url).hostname.replace(/^www\./, "");
        } catch {}
        results.push({ title, url, snippet: snippets[i] || "", domain });
        i++;
      }

      // lite.duckduckgo.com format fallback
      if (results.length === 0) {
        const liteRx =
          /<a[^>]*rel="nofollow"[^>]*href="([^"]+)"[^>]*class=['"]result-link['"][^>]*>([\s\S]*?)<\/a>/g;
        while ((m = liteRx.exec(html)) !== null && results.length < 10) {
          const url = resolveDdgUrl(m[1]);
          const title = decodeEntities(m[2]);
          if (!title || !url.startsWith("http")) continue;
          let domain = "";
          try {
            domain = new URL(url).hostname.replace(/^www\./, "");
          } catch {}
          results.push({ title, url, snippet: "", domain });
        }
      }
      if (results.length > 0) return results;
    } catch {
      // try next endpoint
    }
  }
  return results;
}

export async function POST(req: Request) {
  const { query } = await req.json().catch(() => ({ query: "" }));
  if (!query)
    return Response.json({ error: "Query required" }, { status: 400 });

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));
      try {
        send({ status: "connecting", detail: "Connecting to DuckDuckGo…" });
        send({ status: "querying", detail: `Searching "${query}"…` });
        const results = await ddgSearch(query);
        send({
          status: "found",
          detail: `${results.length} sources found — grinding links…`,
        });
        for (const res of results) {
          send({ result: res });
          // small delay so the client feed feels live
          await new Promise((r) => setTimeout(r, 120));
        }
        const contextText = results
          .map(
            (r, i) =>
              `[${i + 1}] ${r.title}\nURL: ${r.url}\n${r.snippet ? `Snippet: ${r.snippet}` : ""}`
          )
          .join("\n\n");
        send({ done: true, count: results.length, context: contextText });
      } catch (e) {
        send({ error: (e as Error).message });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
