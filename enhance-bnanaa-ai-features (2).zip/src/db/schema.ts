import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  jsonb,
} from "drizzle-orm/pg-core";

export const sessions = pgTable("agent_sessions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default("New Session"),
  model: text("model").notNull().default("auto"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const messages = pgTable("agent_messages", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  role: text("role").notNull(), // user | agent | system
  content: text("content").notNull(),
  messageType: text("message_type").notNull().default("text"),
  metadata: jsonb("metadata").notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const files = pgTable("agent_files", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  filename: text("filename").notNull(),
  content: text("content").notNull().default(""),
  language: text("language").notNull().default("text"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const memory = pgTable("agent_memory", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  key: text("key").notNull(),
  value: text("value").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
